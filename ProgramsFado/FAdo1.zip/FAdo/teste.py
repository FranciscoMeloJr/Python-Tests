#!/usr/bin/env python
from fa import *

a = stringToDFA([1, 0, 1, 2, 3, 0, 2, 4, 2, 1],[1, 1, 1, 1, 0],5,2)
#a = readFromFile("fadn.fa")[0]
x = a.evalNumberOfStateCycles()
print x
