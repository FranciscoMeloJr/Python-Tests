#!/usr/bin/python
# coding=utf-8

# ===================================================
#
# This script will read an NFA discription from a
# txt file and decide whether the language recognized
# by this NFA is a code.CommandCompiler
#
# ===================================================

from cfg import *
from common import *
from fa import *
from reex import *
from unionFind import *

if __name__ == "__main__":

    # Load input file
    inputfile = "test-format1.txt"
    temp = inputfile.replace('.','[2].')
    try: 
       NFA = readFromFile(inputfile)
       print("The input NFA is: ")
       print temp,(NFA[0])
       saveToFile(temp,NFA[0])
    except: 
       print "INVALID format\n"
