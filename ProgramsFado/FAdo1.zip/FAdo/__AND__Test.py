#!/usr/bin/python
# coding=utf-8

from cfg import *
from common import *
from fa import *
from reex import *
from unionFind import *



if __name__ == "__main__":

    # Load input file
    inputfile = "AND.txt"
    FA = readFromFile(inputfile)

    print("The input transducer is: ")
    print(FA[0])

    print("The input language is: ")
    print(FA[1].regexpSE())

    FA[1].addEpsilonTransition()

    newFA = FA[0].__and__(FA[1])
    newFA.trim()
    print(newFA)

    