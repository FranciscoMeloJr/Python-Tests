#!/usr/bin/python
# coding=utf-8

import os, string, re
from cfg import *
from common import *
from fa import *
from reex import *
from unionFind import *

def addLambdaTransitions():
    addLambda = set()
    for index4 in range(len(all_the_text)):
        if (all_the_text[index4][0] != "(START)"):
            addLambda.add(all_the_text[index4][0])
    for numberofadd in range(len(addLambda)):
        addState = addLambda.pop()
        addStateLast = addState + "\n"
        newtransition = [addState, 'lambda', 'lambda', addStateLast]
        all_the_text.append(newtransition)

def startInput(startstate):
    statesSet = set()
    for index in range(len(all_the_text)):
        if (all_the_text[index][0] != "(START)"):
            statesSet.add(all_the_text[index][0])           
    for number in range(len(statesSet)):
        global endState
        endState = statesSet.pop()
        record = []
        StartInputRecursive(startstate, record)

        BufferFile = open("buffer.txt", "w")        
        if len(record) != 0:
            BufferFile.write("@NFA " + endState + "\n")
            for line in range(len(record)):
                BufferFile.write(record[line][0] + " " + record[line][2] + " " + record[line][3])
        BufferFile.close()
        bufferNFA = readFromFile("buffer.txt")
        if len(bufferNFA) != 0:
            print(bufferNFA)
            bufferDFA = bufferNFA[0].toDFA()
            print(bufferDFA)
            print(bufferDFA.regexpSE())
            

def StartInputRecursive(start, record):
    for index in range(len(all_the_text)):
        data = all_the_text[index]
        if (data[0] == start) and (data[1] == "lambda") and (data[2] != "(FINAL\n)"):
            if not all_the_text[index] in record:
                record.append(all_the_text[index])
                newstartstate = all_the_text[index][3][0]
                StartInputRecursive(newstartstate, record)
        if index == len(all_the_text) - 1 and len(record) != 0:
            if endState != record[len(record) - 1][3][0]:
                hasStartState = False
                for line in range(len(record) - 1):
                    if record[len(record) - 1][3][0] == record[line][0]:
                        hasStartState = True
                if not hasStartState:
                    record.remove(record[len(record) - 1])

"""def startInputRecursive(startstate, lastoutput):
    for index1 in range(len(all_the_text)):
        a = all_the_text[index1]
        if (a[0] == startstate) and (a[1] == "lambda") and (a[2] != "lambda"):
            out = lastoutput + a[2]
            nextstate = a[3][0]
            outputintofile = "(START) |- " + nextstate + " " + out + "\n"
            outputFile.write(outputintofile)
            startInputRecursive(nextstate, out)
        if (a[0] == startstate) and (a[1] =="lambda") and (a[2] == "lambda"):
            if lastoutput == "":
                nextstate = a[3][0]
                outputintofile = "(START) |- " + nextstate + " " + "lambda" + "\n"
                outputFile.write(outputintofile)

def transition():
    for index2 in range(len(all_the_text)):
        b = all_the_text[index2]
        if b[0] != "(START)" and b[2] != "(FINAL)":
            if b[1] != "lambda":
                input = b[1]
                nextstate = b[3][0]
                outputRecursive(b[0], nextstate, input, b[2])

def outputRecursive(originstartstate, startstate, origininput, lastoutput):
    outputhere = lastoutput
    for index3 in range(len(all_the_text)):
        c = all_the_text[index3]
        if c[0] != "(START)" and c[2] != "(FINAL)":
            if (c[0] == startstate) and (c[1] == "lambda") and (c[2] != "lambda"):
                if outputhere == "lambda":
                    outputhere = ""
                out = outputhere + c[2]
                nextstate = c[3][0]
                outputintofile = originstartstate + " " + origininput + " " + out + " " + nextstate + "\n"
                outputFile.write(outputintofile)
                outputRecursive(originstartstate, nextstate, origininput, out)
            if (c[0] == startstate) and (c[1] =="lambda") and (c[2] == "lambda"):
                print(lastoutput)
                if lastoutput == "lambda":
                    nextstate = c[3][0]
                    outputintofile = originstartstate + " " + origininput + " " + "lambda" + " " + nextstate + "\n"
                    outputFile.write(outputintofile)"""

                
if __name__ == '__main__':
    #filenameinput = input("Enter the name of input file:")
        
    #inputFile = open(filename, "r")
    inputFile = open("input.txt", "r")
   
    all_the_text = inputFile.readlines()
    inputFile.close()

    for line in range(len(all_the_text)):
        buffer = all_the_text[line].split(" ")
        all_the_text[line] = buffer
    for line in range(len(all_the_text)):
        if all_the_text[line] == "\n":
            all_the_text.remove(['\n'])
    all_the_text[len(all_the_text)-1][2] = "(FINAL)\n"

    addLambdaTransitions()
    #print(all_the_text)
    startInput("1")

    """#filenameoutput = input("Enter the name of output file:")    
    #outputFile = open(filenameoutput, "w")
    outputFile = open("output.txt", "w")
    startInputRecursive("1", "")
    transition()
    
    outputFile.close()"""
    
