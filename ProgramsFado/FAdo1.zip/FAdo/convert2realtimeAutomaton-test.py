#!/usr/bin/python
# coding=utf-8

# =====================================================
#
# This script will read a transducer discription from a
# txt file and translate the transducer to a real-time
# transducer. The result of the translation will be
# displayed by stdout and recorded in a txt file named
# "translateresult.txt" in the same directory.
#
# =====================================================

from cfg import *
from common import *
from fa import *
from reex import *
from unionFind import *

if __name__ == "__main__":

    # Load input file
    inputfile = "convert2realtime-test1.txt"
    Trans = readFromFile(inputfile)

    print("The input transducer is: ")
    print(Trans[0])
    
    # Convert transducer in normal form to real-time transducer    
    realT = Trans[0].toRealTimeAutomatonType()

    print(realT)    
