#!/usr/bin/python
# coding=utf-8

# =====================================================
#
# This script will read a transducer discription from a
# txt file and translate the transducer to a real-time
# transducer. This will be two types of translation. one
# is the type that uses regular expression as the output
# label in the real-time transducer's transitions. The
# other type uses a finite automaton description as the
# output label in the real-time transducer's transition.
# The result of the translation will be displayed by
# stdout and recorded in a txt file named
# "translateresult.txt" in the same directory.
#
# =====================================================

from cfg import *
from common import *
from fa import *
from reex import *
from unionFind import *

if __name__ == "__main__":

    # Load input file
    inputfile = "convert2realtime-test1.txt"
    Trans = readFromFile(inputfile)

    print("The input transducer is: ")
    print(Trans[0])

    # Convert the transducer to normal form.
    normalTran = Trans[0].toNormalForm()

    # Convert the transducer to real-time transducer by
    # finite automaton description type.
    realT = normalTran.toRealTimeAutomatonType()
    print("The real-time transducer in FA type is: ", realT)    
    
    # Convert transducer in normal form to real-time transducer
    # by regular expression type.
    realT = normalTran.toRealTimeREType()
    print("The real-time transducer in RE type is: ", realT)

