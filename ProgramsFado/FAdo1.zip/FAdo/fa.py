#!/usr/bin/python
#!/usr/bin/python
# coding=utf-8

__all__ = ["FA", "NFA", "DFA", "GFA",
           "createPrefixTransducer", "createSuffixTransducer", "createInfixTransducer", "createOutfixTransducer", "createHypercodeTransducer", 
           "isLimitExceed", "readFromFile", "Transducer", "RealTimeTransducer"]

import string, copy
import reex
import re

from common import  *
from unionFind import UnionFind

class FA(object):
    """Base class for Finite Automata.

    This is just a container for some common methods.
    B{Not to be used directly!!}"""

    def __init__(self):
        self.States = []
        self.Sigma = set()
        self.Initial = None
        self.Final = set()
        self.delta = {}

    def __repr__(self):
        return 'FA(%s)' % self.__str__()

    def __str__(self):
        return str((self.States, self.Sigma, self.Initial,
                    self.Final, self.delta))

    def addState(self, name=""):
        """Adds a new state to an FA
        @arg name: Name of the state to be added.
        @type name: string
        @returns: Current number of states (the new state index)
        @rtype: integer"""
        self.States.append(name)
        return (len(self.States)-1)

    def setInitial(self, stateindex):
        """Sets the initial state of a FA
        @arg stateindex: index of the initial state
        @type stateindex: integer"""
        self.Initial = stateindex

    def setFinal(self, statelist):
        """Sets the final states of the FA

        Erases any previous definition of the final state set.
        @arg statelist: a list (or set) of final states (indexes)
        @type statelist: list (or set) of integers"""
        self.Final=set(statelist)

    def addFinal(self, stateindex):
        """A new state is added to the already defined set of final states.
        @arg stateindex: index of the new final state.
        @type stateindex: integer"""
        self.Final.add(stateindex)

    def setSigma(self, symbolSet):
        """Defines the alphabet for the FA.
        @arg symbolSet: accepted symbols
        @type symbolSet: list or set of string"""
        self.Sigma = set(symbolSet)

    def addSigma(self, sym):
        """Adds a new symbol to the alphabet.

        There is no problem with duplicate symbols because Sigma is a Set.
        No symbol Epsilon can be added.
        @arg sym: symbol to be added
        @type sym: string"""
        if sym == Epsilon:
            raise DFAepsilonRedefinition()
        self.Sigma.add(sym)

    def stateName(self, name, autoCreate=False):
        """Index of given state name.

        If the state name is not known and flag is set creates it on the fly,
        otherwise raises an exception.
        @arg name: name of the state
        @type name: string
        @arg autoCreate: flag to create state if not already done
        @type autoCreate: boolean
        @raise DFAstateUnknown: if name given is not known
        @returns: state index
        @rtype: integer"""
        if name in self.States:
            return self.States.index(name)
        else:
            if autoCreate:
                return self.addState(name)
            else:
                raise DFAstateUnknown(name)

    def trim(self):
        """Remove states that do not lead to a final state, or, inclusively,
        can't be reached from the initial state. Only useful states
        remain."""
        useful = self.usefulStates()
        del_states = [s for s in range(len(self.States))
                      if s not in useful]
        if del_states:
            self.deleteStates(del_states)

    def regexpSE(self):
        """A regular expression obtained by state elimination whose
         language is recognised by the FA.

         @returns: the equivalent regular expression
         @rtype: regexp"""
        new = self.dup()
        new.trim()
        if len(new.States)==0:
            return reex.EmptySetConst
        if len(new.Final) == 0: 
            return reex.EmptySetConst
        if len(new.States)==1 and len(new.delta)== 0 :
             return reex.EpsilonConst
        elif type(new) == NFA and len(new.Initial) != 0  and  \
                 len(new.delta)== 0:
            return reex.EpsilonConst        
        
        gfa=new.toGFA()
        if len(gfa.Final) >  1:
             last = gfa.addState("Last")
             for s in gfa.Final:
                 gfa.addTransition(s,Epsilon,last)
             gfa.setFinal([last])
        else: last = list(gfa.Final)[0]
        foo = {}
        lfoo = len(gfa.States)-1
        foo[lfoo], foo[last] = last, lfoo
        gfa.reorder(foo)
        if lfoo != gfa.Initial:
            n = 2
            foo = {}
            foo[lfoo-1],foo[gfa.Initial] =  gfa.Initial, lfoo-1
            gfa.reorder(foo)
        else: n = 1
        lr = range(len(gfa.States)-n)
        gfa.eliminateAll(lr)

        gfa.completeDelta()
        if n == 1: return reex.star(gfa.delta[gfa.Initial][gfa.Initial]).reduced()
        
        ii = gfa.Initial
        fi = list(gfa.Final)[0]
        a = gfa.delta[ii][ii]
        b = gfa.delta[ii][fi]
        c = gfa.delta[fi][ii]
        d = gfa.delta[fi][fi]
        
        #bd*
        re1 = reex.concat(b,reex.star(d))
        #a + bd*c
        re2 = reex.disj(a, reex.concat(re1,c))
        #(a + bd*c)* bd*
        return reex.concat(reex.star(re2),re1).reduced()

class NFA(FA):
    """Class for Non-deterministic Finite Automata
    (epsilon-transitions allowed)."""
    def __init__(self):
        FA.__init__(self)
        self.Initial = set()

    def __repr__(self):
        return "NFA(%s)" % self.__str__()

    def setInitial(self, statelist):
        """Sets the initial states of an NFA
        @arg statelist: an iterable of initial state indexes
        @type statelist: iterable of integers"""
        self.Initial = set(statelist)

    def addInitial(self,stateindex):
        """Add a new state to the set of initial states.
        @arg stateindex: index of new initial state
        @type stateindex: integer"""
        self.Initial.add(stateindex)

    def deleteState(self,sti):
        """Remove given state and transitions related with that state.

        @arg sti: index of the state to be removed.
        @type sti: integer"""
        if sti >= len(self.States):
            raise DFAstateUnknown(sti)
        else:
            if sti in self.delta.keys():
                del self.delta[sti]
            for j in self.delta.keys():
                for sym in self.delta[j].keys():
                    if sti in self.delta[j][sym]:
                        self.delta[j][sym].remove(sti)
                    for k in range(sti+1,len(self.States)):
                        if k in self.delta[j][sym]:
                            self.delta[j][sym].remove(k)
                            self.delta[j][sym].add(k-1)
                    if not len(self.delta[j][sym]):
                        del self.delta[j][sym]
                        if not len(self.delta[j]):
                            del self.delta[j]
            if sti in self.Final:
                self.Final.remove(sti)
            if sti in self.Initial:
                self.Initial.remove(sti)
            for s in self.Initial:
                if sti < s:
                    self.Initial.remove(s)
                    self.Initial.add(s-1)
            for j in range(sti+1,len(self.States)):
                if j in self.delta.keys():
                    self.delta[j-1]=self.delta[j]
            if len(self.States)-1 in self.delta:
                del self.delta[len(self.States)-1]
            del self.States[sti]

    def deleteStates(self, del_states):
        """Delete given iterable collection of states from the
        automaton.

        @note: delta function will always be rebuilt, regardless of
        whether the states list to remove is a suffix, or a sublist,
        of the automaton's states list.

        @arg del_states: collection of integers representing states"""
        rename_map={}
        new_delta = {}
        new_final = set()
        new_states = []
        for state in range(len(self.States)):
            if not state in del_states:
                rename_map[state] = len(new_states)
                new_states.append(self.States[state])
        for state in rename_map:
            if state in self.Final:
                new_final.add(rename_map[state])
            if state not in self.delta:
                continue
            if not len(self.delta[state]) == 0:
                new_delta[rename_map[state]] = {}
            for symbol in self.delta[state]:
                new_targets = set([rename_map[s]
                                   for s in self.delta[state][symbol]
                                   if rename_map.has_key(s)])
                if new_targets:
                    new_delta[rename_map[state]][symbol] = new_targets
        self.States = new_states
        self.delta = new_delta
        self.Final = new_final
        self.Initial = set(map(lambda x: rename_map.get(x,x),self.Initial))

        #Discard useless labels in Sigma
        self.Sigma = set()
        for s in self.delta.keys():
            for n in self.delta[s].keys():
                self.Sigma.add(n)

    def addTransition(self, sti1, sym, sti2):
        """Adds a new transition.

        Transition is from C{sti1} to C{sti2} consuming symbol C{sym}. C{sti2}
        is a unique state, not a set of them.
        @arg sti1: state index of departure
        @arg sti2: state index of arrival
        @arg sym: symbol consumed
        @type sti1: integer
        @type sti2: integer
        @type sym: string"""
        if sym != Epsilon:
            self.Sigma.add(sym)
        if sti1 not in self.delta:
            self.delta[sti1] = {sym: set([sti2])}
        elif sym not in self.delta[sti1]:
            self.delta[sti1][sym] = set([sti2])
        else:
            self.delta[sti1][sym].add(sti2)
        
    def reorder(self,dict):
        """Reorder states indexes according to given dictionary.
        @note: dictionary does not have to be complete
        @type dict: dictionary"""
        if len(dict.keys()) != len(self.States):
            for i in range(len(self.States)):
                if i not in dict.keys():
                    dict[i] = i
        delta = {}
        for s in self.delta.keys():
            delta[dict[s]] = {}
            for c in self.delta[s].keys():
                delta[dict[s]][c] = set()
                for st in self.delta[s][c]:
                    delta[dict[s]][c].add(dict[st])
        self.delta = delta
        self.setInitial(map(lambda x: dict(x,x),self.Initial))
        Final = set()
        for i in self.Final:
            Final.add(dict[i])
        self.Final = Final
        states  = range(len(self.States))
        for i in range(len(self.States)):
            states[dict[i]] = self.States[i]
        self.States = states

    def epsilonP(self):
        """Whether this NFA has epsilon-transitions"""
        return any(map(lambda x: Epsilon in x, self.delta.itervalues()))

    def epsilonClosure(self,st):
        """Returns the set of states epsilon-connected to from given
        state or set of states.

        @attention: C{st} must exist.
        @arg st: state index or set of state indexes
        @type st: integer
        @returns: list of state indexes epsilon connected to C{st}
        @rtype: Set of integer"""
        if type(st) is set:
            s2 = set(st)
        else:
            s2 = set([st])
        s1 = set()
        while s2:
            s = s2.pop()
            s1.add(s)
            s2.update(self.delta.get(s,{}).get(Epsilon,set())-s1)
        return s1

    def evalSymbol(self, stil, sym):
        """Set of states reacheable from given states through given
        symbol and epsilon closure.
        @arg stil: set of current states
        @type stil: set or list of integers
        @arg sym: symbol to be consumed
        @type sym: string
        @returns: set of reached states
        @rtype: set of integers"""
        if sym not in self.Sigma: raise DFAsymbolUnknown(sym)
        res = set()
        if len(stil) == 0: return 0
        for s in stil:
            try: ls = self.delta[s][sym]
            except KeyError:
                ls = set()
            except NameError:
                ls = set()
            for t in ls:
                 res.update(self.epsilonClosure(t))
        return res

    def dup(self):
        """Duplicate the basic structure into a new NFA.
        Basically a copy.deep.
        @rtype: NFA"""
        new = NFA()
        new.setSigma(self.Sigma)
        new.States = self.States[:]
        new.Initial = self.Initial.copy()
        new.Final = self.Final.copy()
        for s in self.delta.keys():
            new.delta[s] = {}
            for c in self.delta[s].keys():
                new.delta[s][c] = self.delta[s][c].copy()
        return new

    def _toNFASingleInitial(self):
        """Construct an equivalent NFA with only one initial state
          @rtype: NFA"""
        nfa = self.dup()
        Initial = nfa.addState("")
        nfa.delta[Initial]={}
        nfa.delta[Initial][Epsilon] = nfa.Initial
        nfa.setInitial([Initial])
        return nfa

    def toDFA(self):
        """Construct a DFA equivalent to this NFA, by the subset
        construction method.
        @note: valid to epsilon-NFA
        @rtype: DFA"""
        dfa = DFA()
        lStates = []
        stl = self.epsilonClosure(self.Initial)
        lStates.append(stl)
        dfa.setInitial(dfa.addState(stl))
        dfa.setSigma(self.Sigma)
        for f in self.Final:
            if f in stl:
                dfa.addFinal(0)
                break
        index = 0
        while True:
            slist = lStates[index]
            si = dfa.stateName(slist)
            for s in self.Sigma:
                stl = self.evalSymbol(slist,s)
                if not stl:
                    continue
                if stl not in lStates:
                    lStates.append(stl)
                    foo = dfa.addState(stl)
                    for f in self.Final:
                        if f in stl:
                            dfa.addFinal(foo)
                            break
                else:
                    foo = dfa.stateName(stl)
                dfa.addTransition(si,s,foo)
            if index == len(lStates) -1: break
            else: index = index + 1
        return dfa

    def hasTransitionP(self, state, symbol=None, target=None):
        """Whether there's a transition from given state, optionally
        through given symbol, and optionally to a specific target.
        @arg state: source state
        @arg symbol: optional transition symbol
        @arg target: optional target state @returns: if there is a
        transition
        @rtype: boolean
        """
        if state not in self.delta:
            return False
        if symbol is None:
            return True
        if symbol not in self.delta[state]:
            return False
        if target is None:
            return self.delta[state][symbol] != set()
        else:
            return target in self.delta[state][symbol]

    def usefulStates(self, initial_states=None):
        """Set of states reacheable from the given initial state(s)
        that have a path to a final state.

        @param initial_states: set of sub-automaton's initial states
        (default: self.Initial)
        @type initial_states: iterable of integers
        @return: set of state indexes
        @rtype: set of integers"""
        if initial_states is None:
            initial_states = self.Initial
        useful=set([s for s in initial_states
                    if s in self.Final])
        stack=list(initial_states)
        preceding={}
        for i in stack:
            preceding[i] = []
        while stack:
            state = stack.pop()
            if not state in self.delta:
                continue
            for symbol in self.delta[state]:
                for adjacent in self.delta[state][symbol]:
                    is_useful = adjacent in useful
                    if adjacent in self.Final or is_useful:
                        useful.add(state)
                        if not is_useful:
                            useful.add(adjacent)
                            preceding[adjacent] = []
                            stack.append(adjacent)
                        inpath_stack = [p for p in preceding[state]
                                        if not p in useful]
                        preceding[state]=[]
                        while inpath_stack:
                            previous = inpath_stack.pop()
                            useful.add(previous)
                            inpath_stack += [p for p in preceding[previous]
                                             if not p in useful]
                            preceding[previous]=[]
                        continue
                    if adjacent not in preceding:
                        preceding[adjacent] = [state]
                        stack.append(adjacent)
                    else:
                        preceding[adjacent].append(state)
        if not useful and self.Initial:
            useful.add(min(self.Initial))
        return useful

    def epsilonPaths(self, start, end):
        """All states in all paths (DFS) through empty words from a given
        starting state to a given ending state.
        @param start: start state
        @param end: end state
        @return: states in epsilon paths from start to end
        @rtype: set of states"""
        inpaths=set()
        stack=[start]
        preceding={start:[]}
        while stack:
            state = stack.pop()
            if self.hasTransitionP(state, Epsilon):
                for adjacent in self.delta[state][Epsilon]:
                    if adjacent is end or adjacent in inpaths:
                        inpaths.add(state)
                        inpath_stack = [p for p in preceding[state]
                                        if not p in inpaths]
                        preceding[state] = []
                        while inpath_stack:
                            previous = inpath_stack.pop()
                            inpaths.add(previous)
                            inpath_stack += [p for p in preceding[previous]
                                             if not p in inpaths]
                            preceding[previous] = []
                        continue
                    if adjacent not in preceding:
                        preceding[adjacent] = [state]
                        stack.append(adjacent)
                    else:
                        preceding[adjacent].append(state)
        return inpaths

    def toGFA(self):
        """ Creates a GFA equivalent to NFA
         @return: GFA deep copy
         @rtype: GFA """
        gfa = GFA()
        gfa.setSigma(self.Sigma)
        #this should be optimized
        fa = self._toNFASingleInitial()
        gfa.Initial = list(fa.Initial)[0]
        gfa.States = fa.States[:]
        gfa.setFinal(fa.Final)
        gfa.predecessors = {}
        for i in range(len(gfa.States)):
            gfa.predecessors[i] = set([])
        for s in fa.delta:
            for c in fa.delta[s]:
                for s1 in fa.delta[s][c]:
                    gfa.addTransition(s,c,s1)
        return gfa

    def __and__(self,other):
        """Conjunction of automata
        @arg other: the right hand operand
        @type other: NFA
        @rtype: NFA
        @raise FAdoGeneralError: if any operand is not an NFA"""
        if type(other) != type(self):
            raise FAdoGeneralError("Incompatible objects")
        
        new = self.product(other)
        for x in [(self.States[a],other.States[b])
                  for a in self.Final for b in other.Final]:
            if x in new.States:
                new.addFinal(new.stateName(x))
        return new

    def product(self, other):
        """ Returns a NFA (skeletom) resulting of
        the simultaneous execution of two DFA.
        No final states are set.
        @arg other: the other automata
        @type other: NFA
        @rtype: NFA
        @attention: the name EmptySet is used in a unique special state name
        @attention: the method uses 3 internal functions
                    for simplicity of code (really!)"""
        
        def sN(a,s):
          try: i = a.stateName(s)
          except DFAstateUnknown:
            return None
          return i
        def kS(a,i):
          if i == None: return set()
          try: ks = a.delta[i].keys()
          except KeyError:
            return set()
          return set(ks)
        def dealT(srcI,dest,symb):
          if not (dest in done or dest in notDone):
            iN = new.addState(dest)
            notDone.append(dest)
          else:
            iN = new.stateName(dest)
          new.addTransition(srcI,k,iN)
        new = NFA()
        new.setSigma(self.Sigma.union(other.Sigma))
        notDone = []
        done = []
        for s1 in [self.States[x] for x in self.Initial]:
          for s2 in [other.States[x] for x in other.Initial]:
            sname = (s1,s2)
            new.addState(sname)
            new.addInitial(new.stateName(sname))
            if (s1,s2) not in notDone: notDone.append((s1,s2))
        while notDone:
          state = notDone.pop()
          done.append(state)
          (s1,s2) = state
          i = new.stateName(state)
          (i1,i2) = (sN(self,s1), sN(other,s2))
          (k1,k2) = (kS(self,i1),kS(other,i2))
          for k in k1.intersection(k2):
            for destination in [(self.States[d1],other.States[d2])
                                for d1 in self.delta[i1][k]
                                for d2 in other.delta[i2][k]]:
              dealT(i,destination,k)
          for k in k1-k2:
            for n in self.delta[i1][k]:
              dealT(i,(self.States[n],EmptySet),k)
          for k in k2-k1:
            for n in other.delta[i2][k]:
              dealT(i,(EmptySet,other.States[n]),k)
        return new         

    def codeP(self):
        """Test whether the language recognized by
        an NFA is a code using Weber's algorithm [Head & Weber, 1993].
        @rtype: boolean
        """

        if self.Initial.issubset(self.Final):
            return False

        Trans = Transducer()
        Trans.States = self.States[:]
        Trans.Initial = self.Initial.copy()
        Trans.Final = self.Initial.copy()
        Trans.Sigma = self.Sigma.copy()
        Trans.Output = set(['1', '0'])

        for start in self.delta.keys():
            for sym in self.delta[start]:
                for end in self.delta[start][sym]:
                    if end not in self.Final:
                        Trans.addTransition(start, sym, '0', end)
                    else:
                        Trans.addTransition(start, sym, '0', end)
                        Trans.addTransition(start, sym, '1',
                                            list(self.Initial)[0])

        Trans.trim()
        standardForm = Trans.generalToStandardForm()
        
        return standardForm.functionalP()

    def addEpsilonTransition(self):
        """Add a transition with epsilon to
        every state in this automaton."""

        stateNum = len(self.States)
        
        for i in range(stateNum):
            self.addTransition(i,Epsilon,i)

    def recognizeOneWord(self):
        """Decide whether the NFA accpets only
           one word. If so, return YES, if not, return NO
        rtype:boolean
        """

        self.trim()

        stateLevel = {}
        notDone = []
        #set level of start state to zero
        for s in self.Initial:
            stateLevel[self.States[s]] = 0
            notDone.append(s)

        labelForEachLevel = {}
        while notDone:
            p = notDone.pop()
            if p in self.delta.keys():
                i = stateLevel[self.States[p]] + 1
                for a in self.delta[p].keys():
                    if i not in labelForEachLevel.keys() or labelForEachLevel[i] == a:
                        labelForEachLevel[i] = a
                    else:
                        return False
                    for q in list(self.delta[p][a]):
                        if self.States[q] not in stateLevel.keys():
                            stateLevel[self.States[q]] = i
                            notDone.append(q)
                        elif (stateLevel[self.States[q]] != i):
                            return False

        return True

class DFA(FA):
    """ Class for Deterministic Finite Automata."""
    def __repr__(self):
        return 'DFA(%s)' % self.__str__()

    def deleteState(self,sti):
        """Remove a state.
        @arg sti: state to be removed.
        @type sti: state index"""
        if sti >= len(self.States):
            raise DFAstateUnknown(sti)
        else:
            if sti in self.delta.keys():
                del self.delta[sti]
            for j in self.delta.keys():
                for sym in self.delta[j].keys():
                    if sti==self.delta[j][sym]:
                        del self.delta[j][sym]
                        if not len(self.delta[j].keys()):
                            del self.delta[j]
                    else:
                        for k in range(sti+1,len(self.States)):
                            if k==self.delta[j][sym]:
                                self.delta[j][sym]=k-1
            if sti in self.Final:
                self.Final.remove(sti)
            if sti == self.Initial:
                self.Initial = None
            elif self.Initial > sti:
                self.Initial -= 1
            for j in range(sti+1,len(self.States)):
                if j in self.delta.keys():
                    self.delta[j-1]=self.delta[j]
            if len(self.States)-1 in self.delta:
                del self.delta[len(self.States)-1]
            del self.States[sti]

    def deleteStates(self, del_states):
        """Delete given iterable collection of states from the
        automaton.

        @note: delta function will always be rebuilt, regardless of
        whether the states list to remove is a suffix, or a sublist,
        of the automaton's states list.

        @arg del_states: collection of integers representing states"""
        if not del_states:
            return
        rename_map = {}
        old_delta = self.delta
        self.delta = {}
        new_final = set()
        new_states = []
        for state in xrange(len(self.States)):
            if not state in del_states:
                rename_map[state] = len(new_states)
                new_states.append(self.States[state])
        for state in rename_map:
            state_renamed = rename_map[state]
            if state in self.Final:
                new_final.add(state_renamed)
            if state not in old_delta:
                continue
            for symbol, target in old_delta[state].iteritems():
                if target in rename_map:
                    self.addTransition(state_renamed, symbol, rename_map[target])
        self.States = new_states
        self.Final = new_final
        self.Initial = rename_map.get(self.Initial, None)

        #Discard useless labels in Sigma
        self.Sigma = set()
        for s in self.delta.keys():
            for n in self.delta[s].keys():
                self.Sigma.add(n)

    def addTransition(self, sti1, sym, sti2):
        """Adds a new transition.

        Transition is from C{sti1} to C{sti2} consuming symbol C{sym}.
        @arg sti1: state index of departure
        @arg sti2: state index of arrival
        @arg sym: symbo, consumed
        @type sti1: state index
        @type sti2: state index
        @type sym: string"""
        if sym == Epsilon:
            raise DFAnotNFA, "Invalid epsilon transition from %s to %s."\
                  %(str(sti1),str(sti2))
        self.Sigma.add(sym)
        if sti1 not in self.delta:
            self.delta[sti1] = {sym:sti2}
        else:
            if sym in self.delta[sti1] and \
                   self.delta[sti1][sym] is not sti2:
                raise DFAnotNFA, "extra transition from (%s,%s)"%(str(sti1),sym)
            self.delta[sti1][sym] = sti2

    def dup(self):
        """Duplicate the basic structure into a new NFA.
        Basically a copy.deep.
        @rtype: NFA"""
        new = DFA()
        new.setSigma(self.Sigma)
        new.States = self.States[:]
        new.Initial = self.Initial
        new.Final = self.Final.copy()
        for s in self.delta.keys():
            new.delta[s] = {}
            for c in self.delta[s].keys():
                new.delta[s][c] = self.delta[s][c]
        return new

    def reorder(self,dict):
        """Reorders states according to given dictionary.

        Given a dictionary (not necessarily complete)...
        reorders states accordingly.
        @type dict: dictionary"""
        if len(dict.keys()) != len(self.States):
            for i in range(len(self.States)):
                if i not in dict.keys():
                    dict[i] = i
        delta = {}
        for s in self.delta.keys():
            delta[dict[s]] = {}
            for c in self.delta[s].keys():
                delta[dict[s]][c] = dict[self.delta[s][c]]
        self.delta = delta
        self.Initial = dict[self.Initial]
        Final = set()
        for i in self.Final:
            Final.add(dict[i])
        self.Final = Final
        states  = range(len(self.States))
        for i in range(len(self.States)):
            states[dict[i]] = self.States[i]
        self.States = states

    def usefulStates(self, initial_states=None):
        """Set of states reacheable from the given initial state(s)
        that have a path to a final state.

        @param initial_states: set of sub-automaton's initial states
        (default: [self.Initial])
        @type initial_states: iterable of integers
        @return: set of state indexes
        @rtype: set of integers"""
        # ATTENTION CODER: This is mostly a copy&paste of
        # NFA.usefulStates(), except that the inner loop for adjacent
        # states is removed, and default initial_states is a list with
        # self.Initial.
        if initial_states is None:
            initial_states = [self.Initial]
            useful = set(initial_states)
        else:
            useful=set([s for s in initial_states
                        if s in self.Final])
        stack=list(initial_states)
        preceding={}
        for i in stack:
            preceding[i] = []
        while stack:
            state = stack.pop()
            if not state in self.delta:
                continue
            for symbol in self.delta[state]:
                adjacent = self.delta[state][symbol]
                is_useful = adjacent in useful
                if adjacent in self.Final or is_useful:
                    useful.add(state)
                    if not is_useful:
                        useful.add(adjacent)
                        preceding[adjacent] = []
                        stack.append(adjacent)
                    inpath_stack = [p for p in preceding[state]
                                    if not p in useful]
                    preceding[state]=[]
                    while inpath_stack:
                        previous = inpath_stack.pop()
                        useful.add(previous)
                        inpath_stack += [p for p in preceding[previous]
                                         if not p in useful]
                        preceding[previous]=[]
                    continue
                if adjacent not in preceding:
                    preceding[adjacent] = [state]
                    stack.append(adjacent)
                else:
                    preceding[adjacent].append(state)
        return useful

    def toGFA(self):
        """ Creates a GFA equivalent to DFA
         @return: GFA deep copy
         @rtype: GFA """
        gfa = GFA()
        gfa.setSigma(self.Sigma)
        gfa.States = self.States[:]
        gfa.setInitial(self.Initial)
        gfa.setFinal(self.Final)
        gfa.predecessors = {}
        for i in range(len(gfa.States)):
            gfa.predecessors[i] = set([])
        for s in self.delta:
            for c in self.delta[s]:
                gfa.addTransition(s,c,self.delta[s][c])
        return gfa

class GFA(FA):
    """ Class for Generalized Finite Automata:
    NFA with a unique initial state and transitions are labeled with regexp."""
    def __repr__(self):
        return 'GFA(%s)' % self.__str__()

    def addTransition(self, sti1, sym, sti2):
        try:
            self.addSigma(sym)
            sym = reex.regexp(sym)
        except DFAepsilonRedefinition:
            sym = reex.EpsilonConst
        if sti1 not in self.delta:
            self.delta[sti1] = {}
        if sti2 not in self.delta[sti1]:
                self.delta[sti1][sti2] = sym
        else: self.delta[sti1][sti2] = reex.disj(self.delta[sti1][sti2],sym)
        try :self.predecessors[sti2].add(sti1)
        except: pass
    
    def reorder(self,dictio):
        """Reorder states indexes according to given dictionary.
        @note: dictionary does not have to be complete
        @type dictio: dictionary"""
        if len(dictio.keys()) != len(self.States):
            for i in range(len(self.States)):
                if i not in dictio.keys():
                    dictio[i] = i
        delta = {}
        preds = {}
        for s in self.delta:
            delta[dictio[s]] = {}
            if dictio[s] not in preds:
                preds[dictio[s]] = set([])
            for s1 in self.delta[s]:
                delta[dictio[s]][dictio[s1]] = self.delta[s][s1]
                if dictio[s1] in preds: preds[dictio[s1]].add(dictio[s])
                else: preds[dictio[s1]] = set([dictio[s]])
        self.delta = delta
        self.predecessors = preds

        self.Initial = dictio[self.Initial]
        Final = set()
        for i in self.Final:
            Final.add(dictio[i])
        self.Final = Final
        states = range(len(self.States))
        for i in range(len(self.States)):
            states[dictio[i]] = self.States[i]
        self.States = states

    def eliminate(self,st):
        """Eliminate a state.
        @param st: state to be eliminated"""
        if st in self.delta and self.delta[st].has_key(st):
            r2 = copy.copy(reex.star(self.delta[st][st]))
            del self.delta[st][st]
        else: r2 = None
        for s in self.delta.keys():
            if not self.delta[s].has_key(st): continue
            r1 = copy.copy(self.delta[s][st])
            del  self.delta[s][st]
            for s1 in self.delta[st].keys():
                r3 =copy.copy(self.delta[st][s1])
                if r2 != None: r = reex.concat(r1,reex.concat(r2,r3))
                else:
                    r = reex.concat(r1,r3)
                if self.delta[s].has_key(s1):
                    self.delta[s][s1]= reex.disj(self.delta[s][s1],r)
                else: self.delta[s][s1] = r
        del self.delta[st]

    def eliminateAll(self,lr):
        """Eliminate a list of states.
        @param lr: list of states indexes"""
        for s in lr:
            self.eliminate(s)
    
    def dup(self):
        """ Returns a copy of a GFA """
        new = GFA()
        new.States = copy.copy(self.States)
        new.Sigma = copy.copy(self.Sigma)
        new.Initial = self.Initial
        new.Final = copy.copy(self.Final)
        new.delta = copy.deepcopy(self.delta)
        new.predecessors = copy.deepcopy(self.predecessors)
        return new

    def deleteState(self,sti):
        """ deletes a state from the GFA """
        newOrder = {}
        for i in range(sti, len(self.States) - 1):
            newOrder[i+1] = i
        newOrder[sti] = len(self.States) - 1
        self.reorder(newOrder)
        st = len(self.States) - 1
        del self.delta[st]
        del self.predecessors[st]
        l = set([])
        for i in self.delta:
            if st in self.delta[i]:
                l.add(i)
        for i in l:
            del self.delta[i][st]
            if len(self.delta[i]) == 0:
                del self.delta[i]
        for i in self.predecessors:
            if st in self.predecessors[i]:
                self.predecessors[i].remove(st)
        del self.States[st]
        
    def eliminateState(self, st):
        """ Deletes a states and updates the automaton
        """
        for i in self.predecessors[st]:
            for j in self.delta[st]:
                if i!=st and j!=st:
                    re = self.delta[i][st]
                    if st in self.delta[st]:
                        re = reex.concat(re, reex.star(self.delta[st][st]))
                    re = reex.concat(re, self.delta[st][j])
                    if j in self.delta[i]:
                        re = reex.disj(self.delta[i][j], re)
                    self.delta[i][j] = re
                    self.predecessors[j].add(i)
        self.deleteState(st)        

    def completeDelta(self):
        """Adds empty set transitions between the automatons final
        and initial states in order to make it complete. It's only
        meant to be used in the final stage of SEA...
        """
        for i in set([self.Initial]+list(self.Final)):
            for j in set([self.Initial]+list(self.Final)):
                if i not in self.delta:
                    self.delta[i] = {}
                if j not in self.delta[i]:
                    self.delta[i][j] = reex.emptyset()

def readFromFile(FileName):
    """Reads a finite automata definition from a file.

    OK the format of these files must be the as simple as possible:

      - '#' begin a comment
      - @DFA or @NFA begin a new automata (and determines its type) and must
      be followed by the list of the final states separated by blanks
      - fields are separated by a blank and transitions by a CR:
      "state" "symbol" "new state"
      - the source state of the first transition is the initial state

    If an error occur, either syntactic or because of a violation of
    the declared automata type, an exception is raised
    @arg FileName: file name
    @type FileName: string
    @rtype: list of FA"""
    try:
        File = open(FileName,"r")
    except IOError:
        raise DFAFileError(FileName)
    
    lst = []
    lnum = 0
    for line in File.readlines():
        lnum = lnum + 1
        if line[0] == "#": continue # a commentary
        linebits = string.split(line)
        if linebits == []: continue # an empty line
        if linebits[0][0] == "@":
            foo = linebits[0][1:]
            initial = True
            if foo == "DFA":
                fa = DFA()
                lst.append(fa)
            elif foo == "NFA" or  foo == "NDFA":
                fa = NFA()
                lst.append(fa)
            elif foo == "Transducer":
                fa = Transducer()
                lst.append(fa)
            elif foo == "RealTimeTransducer":
                fa = RealTimeTransducer()
                lst.append(fa)
            else:
                raise DFASyntaticError(lnum)
            for s in linebits[1:]:
                fa.addFinal(fa.stateName(s,True))
        else:
            st1 = fa.stateName(linebits[0],True)
            if initial:
                if type(fa) is DFA:
                    fa.setInitial(st1)
                else:
                    fa.setInitial([st1])
                initial = False
            if type(fa) is Transducer:
                st2 = fa.stateName(linebits[3],True)
            else:
                st2 = fa.stateName(linebits[2],True)
            if linebits[1] not in fa.Sigma and linebits[1] != Epsilon:
                fa.addSigma(linebits[1])
            if (type(fa) is Transducer) and \
               (linebits[2] not in fa.Output) and (linebits[2] != Epsilon):
                fa.addOutput(linebits[2])
            if type(fa) is Transducer:
                fa.addTransition(st1,linebits[1],linebits[2],st2)
            else:
                fa.addTransition(st1,linebits[1],st2)
    File.close()
    return lst

def saveToFile(FileName,fa):
    """ Saves a finite automata definition to a file using the input format
    @arg FileName: file name
    @type FileName: string
    @arg fa: the FA
    @type fa: FA"""
    try:
        f = open(FileName,"w")
    except IOError:
        raise DFAerror()
    
    if isinstance(fa,DFA):
        f.write("@DFA ")
    else:
        f.write("@NFA ")
    """if fa.Initial != 0:
        foo = {}
        foo[0], foo[fa.Initial] = fa.Initial, 0
        fa.reorder(foo)"""
    for sf in fa.Final:
        f.write("%s " %sf)
    f.write("\n")

    for s in range(len(fa.States)):
        if fa.delta.has_key(s):
            for a in fa.delta[s].keys():
                if isinstance(fa.delta[s][a],set):
                    for s1 in fa.delta[s][a]:
                        f.write("%s %s %s\n" %(s,a,s1))
                else:
                    s1= fa.delta[s][a]
                    f.write("%s %s %s\n" %(s,a,s1))
    f.close()

def NFAGrailToFAdo(FileName):
    """Read a NFA in Grail format and change it to
       FAdo format.
    @arg FileName: file name
    @type FileName: string       
    """
    try:
        FileRead = open(FileName, "r")
        FileWrite = open("Transducer.txt", "w")
    except IOError:
        raise DFAFileError(FileName)

    fileString = FileRead.readlines()
    # Reverse the file string
    fileString.reverse()

    # Store the final states list
    finalStateList = []

    while "FINAL" in fileString[0]:
        element = fileString[0].split()
        finalStateList.append(element[0])
        fileString.pop(0)

    fileString.reverse()

    # Write to a file in FAdo format
    for i in range(len(fileString)):
        if "START" in fileString[i]:
            # Generate start line
            startLine = "@NFA"
            for finalState in finalStateList:
                startLine = startLine + " " + finalState
            startLine += '\n'
            FileWrite.write("%s" %startLine)
        elif "lambda" in fileString[i]:
            newEpsilonStr = fileString[i].replace("lambda", "@epsilon")
            FileWrite.write("%s" %newEpsilonStr)
        else:
            FileWrite.write("%s" %str[i])

    FileRead.close()
    FileWrite.close()

def transducerGrailToFAdo(FileName):
    """Read a Transducer in Grail format and change it to
       FAdo format.
    @arg FileName: file name
    @type FileName: string       
    """
    try:
        FileRead = open(FileName, "r")
        FileWrite = open("NFA.txt", "w")
    except IOError:
        raise DFAFileError(FileName)

    fileString = FileRead.readlines()
    # Reverse the file string
    fileString.reverse()

    # Store the final states list
    finalStateList = []

    while "FINAL" in fileString[0]:
        element = fileString[0].split()
        finalStateList.append(element[0])
        fileString.pop(0)

    fileString.reverse()

    # Write to a file in FAdo format
    for i in range(len(fileString)):
        if "START" in fileString[i]:
            # Generate start line
            startLine = "@Transducer"
            for finalState in finalStateList:
                startLine = startLine + " " + finalState
            startLine += '\n'
            FileWrite.write("%s" %startLine)
        elif "lambda" in fileString[i]:
            newEpsilonStr = fileString[i].replace("lambda", "@epsilon")
            FileWrite.write("%s" %newEpsilonStr)
        else:
            FileWrite.write("%s" %str[i])

    FileRead.close()
    FileWrite.close()

def NFAFAdoToGrail(FileName):
    """Read an NFA in FAdo format and change it
       to Grail format.
    @arg FileName: file name
    @type FileName: string       
    """
    FileWrite = open("../NFA_Grail.txt", "w")

    fileString = FileName.readlines()

    for i in range(len(fileString)):
        if "#" in fileString[i] or fileString[i].split() == []:
            fileString[i] = "\n"
    for i in range(str.count('\n')):
        str.remove('\n')

    startLine = fileString[1].split()
    startState = startLine[0]
    
    FileWrite .write("(START) |- %s \n" %startState)

    for i in range(len(fileString)-1):
        if "@epsilon" in fileString[i+1]:
            newLambdaStr = fileString[i+1].replace("@epsilon", "lambda")
            FileWrite .write("%s" %newLambdaStr)
        else:
            FileWrite .write("%s" %fileString[i+1])

    FileWrite .write("\n")
    
    finalLine = fileString[0].split()
    for i in range(len(finalLine)-1):
        FileWrite .write("%s  -| (FINAL)\n" %finalLine[i+1])

    FileWrite.close()

def transducerFAdoToGrail(FileName):
    """Read a transducer in FAdo format and change it
       to Grail format.
    @arg FileName: file name
    @type FileName: string       
    """
    FileWrite = open("../transducer_Grail.txt", "w")

    fileString = FileName.readlines()

    for i in range(len(fileString)):
        if "#" in fileString[i] or fileString[i].split() == []:
            fileString[i] = "\n"
    for i in range(str.count('\n')):
        str.remove('\n')

    startLine = fileString[1].split()
    startState = startLine[0]
    
    FileWrite .write("(START) |- %s \n" %startState)

    for i in range(len(fileString)-1):
        if "@epsilon" in fileString[i+1]:
            newLambdaStr = fileString[i+1].replace("@epsilon", "lambda")
            FileWrite .write("%s" %newLambdaStr)
        else:
            FileWrite .write("%s" %fileString[i+1])

    FileWrite .write("\n")
    
    finalLine = fileString[0].split()
    for i in range(len(finalLine)-1):
        FileWrite .write("%s  -| (FINAL)\n" %finalLine[i+1])

    FileWrite.close()

def createPrefixTransducer(alphabetList):
    """Create a prefix property transducer based on the alphabet in
       the user's uploaded NFA.
    @arg alphabetList: alphabet list
    @type FileName: list
    """
    
    file = open("prefix.txt", "w")

    # Write the start line into the file
    file.write("(START) |- 0 \n")

    # Write each transition based on definition of prefix property
    for s in alphabetList:
        file.write("0 %s %s 0\n" %(s, s))
        file.write("0 %s lambda 1\n" %s)
        file.write("1 %s lambda 1\n" %s)

    # Write the final line into the file
    file.write("1 -| (FINAL)\n")

    # Close file stream
    file.close()

def createSuffixTransducer(alphabetList):
    """Create a suffix property transducer based on the alphabet in
       the user's uploaded NFA.
    @arg alphabetList: alphabet list
    @type FileName: list       
    """
    
    file = open("suffix.txt", "w")

    # Write the start line into the file
    file.write("(START) |- 0 \n")

    # Write each transition based on definition of suffix property
    for s in alphabetList:
        file.write("0 %s lambda 0\n" %s)
        file.write("0 %s lambda 1\n" %s)
        file.write("1 %s %s 1\n" %(s, s))

    # Write the final line into the file
    file.write("1 -| (FINAL)\n")

    # Close file stream
    file.close()

def createInfixTransducer(alphabetList):
    """Create a infix property transducer based on the alphabet in
       the user's uploaded NFA.
    @arg alphabetList: alphabet list
    @type FileName: list       
    """
    
    file = open("infix.txt", "w")

    # Write the start line into the file
    file.write("(START) |- 0 \n")

    # Write each transition based on definition of infix property
    for s in alphabetList:
        file.write("0 %s lambda 1\n" %s)
        file.write("1 %s lambda 1\n" %s)
        file.write("1 %s %s 2\n" %(s, s))
        file.write("2 %s %s 2\n" %(s, s))
        file.write("2 %s lambda 3\n" %s)
        file.write("3 %s lambda 3\n" %s)
        file.write("0 %s %s 4\n" %(s, s))
        file.write("4 %s %s 4\n" %(s, s))
        file.write("4 %s lambda 3\n" %s)

    # Write the final lines into the file
    file.write("1 -| (FINAL)\n")
    file.write("2 -| (FINAL)\n")
    file.write("3 -| (FINAL)\n")

    # Close file stream
    file.close()

def createOutfixTransducer(alphabetList):
    """Create a outfix property transducer based on the alphabet in
       the user's uploaded NFA.
    @arg alphabetList: alphabet list
    @type FileName: list       
    """
    
    file = open("outfix.txt", "w")

    # Write the start line into the file
    file.write("(START) |- 0 \n")

    # Write each transition based on definition of outfix property
    for s in alphabetList:
        file.write("0 lambda %s 1\n" %s)
        file.write("1 lambda %s 1\n" %s)
        file.write("1 %s %s 2\n" %(s, s))
        file.write("2 %s %s 2\n" %(s, s))
        file.write("2 lambda %s 3\n" %s)
        file.write("3 lambda %s 3\n" %s)
        file.write("0 %s %s 4\n" %(s, s))
        file.write("4 %s %s 4\n" %(s, s))
        file.write("4 lambda %s 3\n" %s)

    # Write the final lines into the file
    file.write("1 -| (FINAL)\n")
    file.write("2 -| (FINAL)\n")
    file.write("3 -| (FINAL)\n")

    # Close file stream
    file.close()
    
def createHypercodeTransducer(alphabetList):
    """Create a hypercode property transducer based on the alphabet in
       the user's uploaded NFA.
    @arg alphabetList: alphabet list
    @type FileName: list       
    """
    
    file = open("hypercode.txt", "w")

    # Write the start line into the file
    file.write("(START) |- 0 \n")

    # Write each transition based on definition of hypercode property
    for s in alphabetList:
        file.write("0 %s lambda 0\n" %s)
        file.write("0 %s %s 0\n" %(s, s))
        file.write("0 %s lambda 1\n" %s)
        file.write("1 %s lambda 1\n" %s)
        file.write("1 %s %s 1\n" %(s, s))

    # Write the final line into the file
    file.write("1 -| (FINAL)\n")

    # Close file stream
    file.close()

def isLimitExceed(NFA0Delta, NFA1Delta, bothNFA = False):
    """Decide if the size of NFA0 and NFA1 exceed the limit.
       Size of NFA0 is denoted as N, and size of NFA1 is denoted as M.
       If N*N*M exceeds 1000000, return False, else return True.
       If bothNFA is False, then NFA0 should be NFA, and NFA1 should be
       Transducer. If bothNFA is True, then NFA0 and NFA1 are both NFAs.

    @arg NFA0Delta: NFA0's transition Delta
    @type NFA0Delta: Dictionary
    @arg NFA1Delta: NFA1's transition Delta
    @type NFA1Delta: Dictionayr
    @arg bothNFA: boolean to decide if NFA0 and NFA1 are both NFAs
    @type bothNFA: boolean
    rtype"""

    N = 0
    for s in NFA0Delta.keys():
        for str in NFA0Delta[s]:
            N = N + len(NFA0Delta[s][str])

    M = 0
    for s in NFA1Delta.keys():
        for str in NFA1Delta[s]:
            M = M + len(NFA1Delta[s][str])

    if N*N*M > 1000000:
        return True
    else:
        return False

class Transducer(NFA):    
    """Base class for Transducer.
    This is just a container for some common methods."""
    
    def __init__(self):
        """Initialize the transducer."""
        
        NFA.__init__(self)

        # A set to store the output alphabet of this transducer
        self.Output = set()
        
    def __str__(self):
        """Return a string representing the details
        of the current transducer instance."""
        
        return str((self.States, self.Sigma, self.Output, self.Initial,
                    self.Final, self.delta))

    def __repr__(self):
        """Return a string adding type 'Transducer'
        in front of the representation"""
        
        return 'Transducer(%s)' % self.__str__()

    def setInitial(self, statelist):
        """Sets the initial state of a Transducer
        @arg stateindex: index of the initial state
        @type stateindex: integer"""
        
        self.Initial = set(statelist)

    def addOutput(self, sym):
        """Add a new symbol to the output alphabet.

        There is no problem with duplicate symbols because Output is a Set.
        No symbol Epsilon can be added.
        @arg sym: symbol or regular expression to be added
        @type sym: string"""
        if sym == Epsilon:
            #TODO: Check this error
            raise DFAepsilogRedefinition()
        self.Output.add(sym)

    def addTransition(self, sti1, sym1, sym2, sti2):
        """Adds a new transition.

        @arg sti1: state index of departure
        @arg sti2: state index of arrival
        @arg sym1: symbol consumed
        @arg sym2: symbol output
        @type sti1: integer
        @type sti2: integer
        @type sym1: string
        @type sym2: string"""

        #Add two alphabets to Sigma and Output if they're not Epsilon.
        if sym1 != Epsilon:
            self.Sigma.add(sym1)
        if sym2 != Epsilon:
            self.Output.add(sym2)

        #Is the start state of this transition a key of delta dictionary?
        if sti1 not in self.delta:
            self.delta[sti1] = {sym1: [[sym2, set([sti2])]]}

        #Start state is a key of delta dictionary
        #Is the input label a key of delta[sti1]?
        elif sym1 not in self.delta[sti1]:
            self.delta[sti1][sym1] = [[sym2, set([sti2])]]

        #Add the transition to delta dictionary
        else:
            self.delta[sti1][sym1].append([sym2, set([sti2])])

    def delOutput(self):
        """Delete the output labels in the transducer.
        Translate it into an NFA.
        @rtype: NFA"""

        #Initialize a new NFA instance
        fa = NFA()

        #Copy transducer's input sigma to NFA's sigma
        fa.setSigma(self.Sigma)

        #Copy transducer's every state to NFA's state
        fa.States = self.States[:]

        #Copy transducer's initial state to NFA's initial state
        fa.Initial = self.Initial.copy()

        #Copy transducer's Final states to NFA's final states
        fa.Final = self.Final.copy()

        #Delete the output label in the transducer
        for s in self.delta.keys():
            fa.delta[s] = {}
            for c in self.delta[s].keys():
                fa.delta[s][c] = set()
                for i in range(len(self.delta[s][c])):
                    fa.delta[s][c] = fa.delta[s][c].union\
                                     (self.delta[s][c][i][1])
        
        return fa
    
    def toRealTimeREType(self):
        """Translate a Transducer into an equivalent
        real-time Transducer. The output label of
        this real-time transducer contains regular
        expressions.
        @rtype: RealTimeTransducer"""

        def addInitialOutput():
            """Calculate the initial output of start state.
            Output should be in form of regular expression.
            Add the output to the initial state in the new
            real-time transducer.
            """

            for i in epsilonClosure:

                #Initialize an NFA instance to calculate the regular expression
                #this NFA recognized
                nfa = NFA()

                #Calculate the epsilon path from start state s to end state i
                statePaths = T.epsilonPaths(s, i)

                #Set end state i to be nfa's final state
                nfa.addFinal(nfa.stateName(self.States[i], True))

                #Set start state s to be nfa's start state
                nfa.setInitial([nfa.stateName(self.States[s], True)])

                #Add end state i itself to epsilon path
                statePaths.add(i)

                #Add every transition in the epsilon path to nfa's delta
                for j in statePaths:

                    #If state j is not nfa's state, add it
                    nfa.stateName(self.States[j], True)

                    #Iterating the transition that has input label Epsilon
                    if self.delta.has_key(j) and self.delta[j].has_key(Epsilon):
                        for index in range(len(self.delta[j][Epsilon])):

                            #Find the endState of the transition that starts
                            #with state j and input label Epsilon
                            endState = self.delta[j][Epsilon][index][1].copy()

                            #If endState in the statePaths, then add the transition
                            if endState.issubset(statePaths):

                                #Get the start, label and end of the transition
                                st1 = nfa.stateName(self.States[j], True)
                                label = self.delta[j][Epsilon][index][0]
                                st2 = nfa.stateName(
                                    self.States[endState.pop()], True)

                                #Add the label to nfa's sigma
                                if label != Epsilon:
                                    nfa.addSigma(label)

                                #Add this transition to nfa's delta
                                nfa.addTransition(st1, label, st2)

                            del endState

                # Add the regular expression this nfa recognized to
                # fa's initial output 
                fa.Initial[self.States[i]] = str(nfa.toDFA().regexpSE())
                fa.stateName(self.States[i], True)
                
        def addOutput():
            """Calculate the output of every state in the transducer.
            Output should be in the form of regular expression.
            Add the output to every state in the new real-time
            transducer.
            """

            for j in epsilonClosure:

                #Initialize an NFA instance to calculate the regular expression
                #this NFA recognized
                nfa = NFA()

                #Calculate the epsilon path from start state startState
                # to end state j
                statePaths = T.epsilonPaths(startState, j)

                #startState does not have any epsilon path
                if len(statePaths) == 0:

                    #Set the start and end state, input and output label
                    st1 = fa.stateName(self.States[s], True)
                    sym1 = c
                    sym2 = Epsilon
                    st2 = fa.stateName(self.States[j], True)

                    #Add the input label to fa's Sigma
                    if sym1 not in fa.Sigma:
                        fa.addSigma(sym1)

                    #Add this transition to fa's delta
                    fa.addTransition(st1, sym1, sym2, st2)

                #startState has a epsilon path
                else:

                    #Set state j to final state of the constructed nfa
                    nfa.addFinal(nfa.stateName(self.States[j], True))

                    #Set startState to initial state of the constructed nfa
                    nfa.setInitial([nfa.stateName(self.States[startState],
                                                  True)])

                    #Add end state j itself to the epsilon path
                    statePaths.add(j)

                    #Add every transition in the epsilon path to nfa's delta
                    for n in statePaths:

                        #If state n is not nfa's state, add it
                        nfa.stateName(self.States[n], True)

                        #Iterating the transition that has input label Epsilon
                        if self.delta.has_key(n) and \
                            self.delta[n].has_key(Epsilon):
                            for index in range(len(self.delta[n][Epsilon])):

                                #Find the endState of the transition that starts
                                #with state n and input label Epsilon
                                endState = self.delta[n][Epsilon][index][1].copy()

                                #If endState in the statePaths, add transition
                                if endState.issubset(statePaths):
                                #Get the start, label and end of the transition
                                    st1 = nfa.stateName(self.States[n], True)
                                    label = self.delta[n][Epsilon][index][0]
                                    st2 = nfa.stateName(
                                        self.States[endState.pop()], True)

                                    #Add the label to nfa's sigma
                                    if label != Epsilon:
                                        nfa.addSigma(label)
                                        
                                    #Add this transition to nfa's delta
                                    nfa.addTransition(st1, label, st2)

                                del endState

                    #Add transition to fa's delta
                    st1 = fa.stateName(self.States[s], True)
                    sym1 = c
                    sym2 = str(nfa.toDFA().regexpSE())
                    st2 = fa.stateName(self.States[j], True)
                    fa.addSigma(sym1)

                    if sym2 != Epsilon:
                        fa.addOutput(sym2)

                    fa.addTransition(st1, sym1, sym2, st2)

        #Initialize a real time transducer instance
        fa = RealTimeTransducer()

        #Delete the output labels in this transducer
        T = self.delOutput()

        #Add output to initial start states
        for s in self.Initial:

            #Add this state to new fa's states
            if self.States[s] not in fa.States:
                fa.stateName(self.States[s], True)
                
            #Do start states have transition with Epsilon input
            #going out from it?
            if Epsilon not in self.delta[s].keys():

                #If not, initial output of start state is set to Epsilon
                fa.Initial[self.States[s]] = Epsilon
            else:

                #Find the epsilon closure of start state
                epsilonClosure = T.epsilonClosure(s)

                #Calculate the initial output of start state
                addInitialOutput()

        #For every transition with non Epsilon input,
        #find the end state in this transition
        for s in self.delta.keys():
            for c in self.delta[s].keys():
                if c != Epsilon:
                    for index in range(len(self.delta[s][c])):
                        startState = self.delta[s][c][index][1].copy().pop()

                        #Find the epsilonClousre of this end state
                        epsilonClosure = T.epsilonClosure(startState)

                        #Calculate the output of every state
                        #in real time transducer
                        addOutput()
                        
        #Set the final state of fa
        for s in self.Final:
            fa.addFinal(fa.stateName(self.States[s],True))
        return fa

    def toRealTimeAutomatonType(self):
        """Translate a Transducer into an equivalent
        real-time transducer. The output label of this
        real-time transducer is an automata. Export a file
        records all the descriptions of the automaton.
        """
        
        def addInitialOutput():
            """Calculate the initial output of start state.
            Output should be in form of regular expression.
            Add the output to the initial state in the new
            real-time transducer.
            """

            for i in epsilonClosure:

                #Initialize an NFA instance to calculate the regular expression
                #this NFA recognized
                nfa = NFA()

                #Calculate the epsilon path from start state s to end state i
                statePaths = T.epsilonPaths(s, i)

                #Set end state i to be nfa's final state
                nfa.addFinal(nfa.stateName(self.States[i], True))

                #Set start state s to be nfa's start state
                nfa.setInitial([nfa.stateName(self.States[s], True)])

                #Add end state i itself to epsilon path
                statePaths.add(i)

                #Add every transition in the epsilon path to nfa's delta
                for j in statePaths:

                    #If state j is not nfa's state, add it
                    nfa.stateName(self.States[j], True)

                    #Iterating the transition that has input label Epsilon
                    if self.delta.has_key(j) and self.delta[j].has_key(Epsilon):
                        for index in range(len(self.delta[j][Epsilon])):

                            #Find the endState of the transition that starts
                            #with state j and input label Epsilon
                            endState = self.delta[j][Epsilon][index][1].copy()

                            #If endState in the statePaths, add the transition
                            if endState.issubset(statePaths):

                                #Get the start, label and end of the transition
                                st1 = nfa.stateName(self.States[j], True)
                                label = self.delta[j][Epsilon][index][0]
                                st2 = nfa.stateName(
                                    self.States[endState.pop()], True)

                                #Add the label to nfa's sigma
                                if label != Epsilon:
                                    nfa.addSigma(label)

                                #Add this transition to nfa's delta
                                nfa.addTransition(st1, label, st2)

                            del endState

                #Write this NFA instance to the file
                f.write("\n@NFA(%s)-(%s) \n"
                        %(nfa.States[list(nfa.Initial)[0]],
                          nfa.States[list(nfa.Final)[0]]))

                #Write the start states
                f.write("Start States: ")
                for sf in nfa.Initial:
                    f.write("%s " %nfa.States[sf])
                f.write("\n")

                #Write the final states
                f.write("Final States: ")
                for sf in nfa.Final:
                    f.write("%s " %nfa.States[sf])
                f.write("\n")

                #Write the transition
                for s1 in range(len(nfa.States)):
                    if nfa.delta.has_key(s1):
                        for a in nfa.delta[s1].keys():
                            if isinstance(nfa.delta[s1][a], set):
                                for s2 in nfa.delta[s1][a]:
                                    f.write("%s %s %s\n" %(nfa.States[s1],
                                                           a, nfa.States[s2]))
                            else:
                                s2 = nfa.delta[s1][a]
                                f.write("%s %s %s\n" %(nfa.States[s1],
                                                       a, nfa.States[s2]))

                # Add the NFA's name to fa's initial output
                fa.Initial[self.States[i]] = "@NFA(%s)-(%s) " \
                                             %(nfa.States[list(nfa.Initial)[0]],
                                               nfa.States[list(nfa.Final)[0]])
                fa.stateName(self.States[i], True)

        def addOutput():
            """Calculate the output of every state in the transducer.
            Output should be in the form of regular expression.
            Add the output to every state in the new real-time
            transducer.
            """

            for j in epsilonClosure:

                #Initialize an NFA instance to calculate the regular expression
                #this NFA recognized
                nfa = NFA()

                #Calculate the epsilon path from start state s to end state i
                statePaths = T.epsilonPaths(startState, j)

                #startState does not have any epsilon path
                if len(statePaths) == 0:

                    #Set the start and end state, input and output label
                    st1 = fa.stateName(self.States[s], True)
                    sym1 = c
                    sym2 = Epsilon
                    st2 = fa.stateName(self.States[j], True)

                    #Add the input label to fa's Sigma
                    if sym1 not in fa.Sigma:
                        fa.addSigma(sym1)

                    #Add this transition to fa's delta
                    fa.addTransition(st1, sym1, sym2, st2)

                #startState has a epsilon path
                else:

                    #Set state j to final state of the constructed nfa
                    nfa.addFinal(nfa.stateName(self.States[j], True))

                    #Set startState to initial state of the constructed nfa
                    nfa.setInitial([nfa.stateName(self.States[startState],
                                                  True)])

                    #Add end state j itself to the epsilon path
                    statePaths.add(j)

                    #Add every transition in the epsilon path to nfa's delta
                    for n in statePaths:

                        #If state n is not nfa's state, add it
                        nfa.stateName(self.States[n], True)

                        #Iterating the transition that has input label Epsilon
                        if self.delta.has_key(n) and \
                            self.delta[n].has_key(Epsilon):
                            for index in range(len(self.delta[n][Epsilon])):

                                #Find the endState of the transition that starts
                                #with state n and input label Epsilon
                                endState = self.delta[n][Epsilon][index][1].copy()

                                #If endState in the statePaths, add transition
                                if endState.issubset(statePaths):
                                #Get the start, label and end of the transition
                                    st1 = nfa.stateName(self.States[n], True)
                                    label = self.delta[n][Epsilon][index][0]
                                    st2 = nfa.stateName(
                                        self.States[endState.pop()], True)

                                    #Add the label to nfa's sigma
                                    if label != Epsilon:
                                        nfa.addSigma(label)
                                        
                                    #Add this transition to nfa's delta
                                    nfa.addTransition(st1, label, st2)

                                del endState

                    #Write this NFA instance to the file            
                    f.write("\n@NFA(%s)-(%s) \n"
                            %(nfa.States[list(nfa.Initial)[0]],
                              nfa.States[list(nfa.Final)[0]]))

                    #Write the start states                    
                    f.write("Start States: ")
                    for sf in nfa.Initial:
                        f.write("%s " %nfa.States[sf])
                    f.write("\n")

                    #Write the final states
                    f.write("Final States: ")
                    for sf in nfa.Final:
                        f.write("%s " %nfa.States[sf])
                    f.write("\n")

                    #Write the transition
                    for t in range(len(nfa.States)):
                        if nfa.delta.has_key(t):
                            for a in nfa.delta[t].keys():
                                if isinstance(nfa.delta[t][a], set):
                                    for s1 in nfa.delta[t][a]:
                                        f.write("%s %s %s\n"
                                                %(nfa.States[t],
                                                  a, nfa.States[s1]))
                                else:
                                    s1 = nfa.delta[t][a]
                                    f.write("%s %s %s\n"
                                            %(nfa.States[t],
                                              a, nfa.States[s1]))

                    # Add the NFA's name to fa's transition                
                    st1 = fa.stateName(self.States[s], True)
                    sym1 = c
                    sym2 = "@NFA(%s)-(%s) " %(nfa.States[list(nfa.Initial)[0]],
                                           nfa.States[list(nfa.Final)[0]])
                    st2 = fa.stateName(self.States[j], True)
                    
                    if sym2 != Epsilon:
                        fa.addOutput(sym2)
                        
                    fa.addTransition(st1, sym1, sym2, st2)

        #Save the result to a file        
        self.saveToFile("translateresult.txt")
        
        try:
            f = open("translateresult.txt", "a")
        except IOError, ex:
            print("Error occured when trying to open a file: " + str(ex))

        #Initialize a new real time transducer instance        
        fa = RealTimeTransducer()

        #Delete the output labels in this transducer        
        T = self.delOutput()

        #Add output to initial start states        
        for s in self.Initial:

            #Add this 's' state to new fa's states
            if self.States[s] not in fa.States:
                fa.stateName(self.States[s], True)

            #Do start states have transition with Epsilon input
            #going out from it?
            if Epsilon not in self.delta[s].keys():

                #If not, initial output of start state is set to Epsilon   
                fa.Initial[self.States[s]] = Epsilon

            else:

                #Find the epsilon closure of start state                 
                epsilonClosure = T.epsilonClosure(s)

                #Calculate the initial output of start state
                addInitialOutput()

        #For every transition with non Epsilon input,
        #find the end state in this transition
        for s in self.delta.keys():
            for c in self.delta[s].keys():
                if c != Epsilon:
                    for index in range(len(self.delta[s][c])):
                        startState = self.delta[s][c][index][1].copy().pop()

                        #Find the epsilonClousre of this end state
                        epsilonClosure = T.epsilonClosure(startState)

                        #Calculate the output of every state
                        #in real time transducer
                        addOutput()

        #Set the final state of fa
        for s in self.Final:
            fa.addFinal(fa.stateName(self.States[s], True))

        f.write("\nMAIN:\n")
        f.close()

        #Write the main real time transducer instance to the file        
        fa.saveToFile("translateresult.txt", "a")

        return fa        

    def __and__(self, other):
        """ Conjunction of transducer and automata: X & Y.
        Arg:
            other: the automata needs to be operated.
        @rtype: Transducer"""

        #If automata's type is incompatible, raise FAdoGeneralError
        if type(other) != NFA and type(other) != DFA:
            #TODO: Check this error
            raise FAdoGeneralError ("Incompatible objects")

        #Conjunction of transducer and automaton
        new = self.product(other)

        #Set x to the new automata's final state
        for x in [(self.States[a], other.States[b])
                  for a in self.Final for b in other.Final]:
            if x in new.States:
                new.addFinal(new.stateName(x))

        return new

    def product(self, other):
        """ Returns a transducer (skeletom) resulting of
        the simultaneous execution of a transducer and an automaton.
        Arg:
            other: the automata needs to be operated.
        @rtype: Transducer
        """
        
        def sN(a, s):
            """Find the index of state s.
            """
            
            try:
                i = a.stateName(s)
            except DFAstateUnknown:
                return None
            
            return i
        
        def kS(a, i ):
            """Find the input label coming out of state i.
            """
            
            if i == None:
                return set()
            
            try:
                ks = a.delta[i].keys()
            except KeyError:
                return set()
            
            return set(ks)
        
        def dealT(srcI, dest, symb, out):
            """Add transition to the new transducer instance.
            """
            
            if not (dest in done or dest in notDone):
                iN = new.addState(dest)
                notDone.append(dest)
            else:
                iN = new.stateName(dest)
                
            new.addTransition(srcI, symb, out, iN)

        #Initialize a new transducer instance            
        new = Transducer()

        #Conjunct the transducer's sigma and automata's sigma        
        new.setSigma(self.Sigma.union(other.Sigma))

        #List to store states that have not been operated        
        notDone = []

        #List to store states that have been operated        
        done = []

        #Set (s1, s2) to be the initial start state of new transducer
        #s1 is the start state of transudcer
        #s2 is the start state of automata
        for s1 in [self.States[x] for x in self.Initial]:
            for s2 in [other.States[x] for x in other.Initial]:
                sname = (s1, s2)
                new.addState(sname)
                new.addInitial(new.stateName(sname))
                
                if (s1, s2) not in notDone:
                    notDone.append((s1, s2))

        #Some states in the notDone list
        while notDone:

            #Get the state needs to operate from the notDone list            
            state = notDone.pop()

            #Store the state to done list            
            done.append(state)
            
            (s1, s2) = state
            i = new.stateName(state)
            
            (i1, i2) = (sN(self, s1), sN(other, s2))
            (k1, k2) = (kS(self, i1), kS(other, i2))

            #State i1 and i2 have the same input label coming out from them   
            for k in k1.intersection(k2):
                for n in xrange(len(self.delta[i1][k])):
                    for destination in [(self.States[d1], other.States[d2])
                                        for d1 in self.delta[i1][k][n][1]\
                                        for d2 in other.delta[i2][k]]:

                        #Get the output label from transducer         
                        outlabel = self.delta[i1][k][n][0]

                        #Add transition to the new transducer instance         
                        dealT(i, destination, k, outlabel)

            #State i1 has some input labels that state i2 doesn't have
            for k in k1 - k2:
                for n in xrange(len(self.delta[i1][k])):

                    #Get the output label from transducer                    
                    outlabel = self.delta[i1][k][n][0]
                    
                    destination = list(self.delta[i1][k][n][1])[0]

                    #Add transition to the new transducer instance             
                    dealT(i, (self.States[destination], EmptySet), k, outlabel)

            #State i2 has some input labels that state i1 doesn't have
            for k in k2 - k1:
                for n in other.delta[i2][k]:

                    #Add transition to the new transducer instance            
                    dealT(i, (EmptySet, other.States[n]), k, Epsilon)

        return new

    def compositionOperation(self, other):
        """Composition operation of self transducer and
           other transducer.
           @arg other: the transducer needs to be operated.
           @rtype: Transducer
        """

        #If other's type is not transducer, raise FAdoGeneralError
        if type(other) != Transducer:
            raise FAdoGeneralError("Incompatible objects")

        def sN(a, s):
            """Find the index of state s.
            """

            try:
                i = a.stateName(s)
            except DFAstateUnknown:
                return None

            return i

        def inputS(a, i):
            """Find the input label coming out of state i.
            """

            if i == None:
                return set()

            try:
                inputS = a.delta[i].keys()
            except KeyError:
                return set()

            return set(inputS)

        def outputS(a, i):
            """Find the output label coming out of state i.
            """

            if i == None:
                return set()

            outputS = []
            if i in a.delta.keys():
                for inputLabel in a.delta[i].keys():
                    #Get the output label coming out of state i
                    for index in range(len(a.delta[i][inputLabel])):
                        outputLabel = a.delta[i][inputLabel][index][0]
                        outputS.append(outputLabel)
            else:
                return set()

            return set(outputS)

        def dealT(start, end, inputLabel, outputLabel):
            """Add transition to the new transducer instance.
            """

            if not (end in done or end in notDone):
                iN = new.addState(end)
                notDone.append(end)
            else:
                iN = new.stateName(end)

            new.addTransition(start, inputLabel, outputLabel, iN)

        #Initialize a new transducer instance
        new = Transducer()

        #List to store states that have not been operated
        notDone = []

        #List to store states that have been operated
        done = []

        #Set (s1, s2) to be the initial start state of new transducer
        #s1 is the start state of self transducer
        #s2 is the start state of other transducer
        for s1 in [self.States[x] for x in self.Initial]:
            for s2 in [other.States[x] for x in other.Initial]:
                sname = (s1, s2)
                new.addState(sname)
                new.addInitial(new.stateName(sname))

                if (s1, s2) not in notDone:
                    notDone.append((s1, s2))

        #Some states in the notDone list
        while notDone:

            #Get the state needs to operate from the notDone list
            state = notDone.pop()

            #Store the state to done list
            done.append(state)

            (s1, s2) = state
            i = new.stateName(state)

            (i1, i2) = (sN(self, s1), sN(other, s2))
            #Find the output label in the transition coming out of self transducer
            #Fidd the input label in the transition coming out of other transducer
            (k1, k2) = (outputS(self, i1), inputS(other, i2))

            #State i1's output labels are the same with i2's input labels
            for k in k1.intersection(k2):
                for s in self.delta[i1].keys():
                    for n in xrange(len(self.delta[i1][s])):
                        if self.delta[i1][s][n][0] == k:
                            #Get the inputlabel and end state in the transition
                            #in which the output label of the transition equals k
                            #from self transducer
                            inputLabel = s
                            d1 = iter(self.delta[i1][s][n][1]).next()
                            
                            #Get the outputlabel and end state in the transition
                            #in which the input label of the transition equals k
                            #from other transudcer
                            for index2 in xrange(len(other.delta[i2][k])):
                                outputLabel = other.delta[i2][k][index2][0]
                                d2 = iter(other.delta[i2][k][index2][1]).next()

                                #Add transition to the new transducer instance
                                dealT(i, (self.States[d1], other.States[d2]), inputLabel, outputLabel)

        #Set x to the new transducer's final state
        for x in [(self.States[a], other.States[b])
                  for a in self.Final for b in other.Final]:
            if x in new.States:
                new.addFinal(new.stateName(x))

        return new

    def functionalMohri(self):
        """Tests if a composition transducer is functional
           using Mohri's algorithm.
           If it's functional, return True. If it's not, return False
        @rtype: Boolean
        """

        notDone = []
        done = {}

        for s in self.Initial:
            notDone.append(s)                
            #Give (epsilon, epsilon) to the initial state
            done[s] = (Epsilon, Epsilon)

        while notDone:
            start = notDone.pop()
            (preInput, preOutput) = done[start]

            if start in self.delta.keys():
                for input in self.delta[start].keys():

                    #Get the end states
                    for index in xrange(len(self.delta[start][input])):
                        output = self.delta[start][input][index][0]
                        end = iter(self.delta[start][input][index][1]).next()

                        if preInput == Epsilon:
                            newInput = input
                        elif input == Epsilon:
                            newInput = preInput
                        else:
                            newInput = preInput + input

                        if preOutput == Epsilon:
                            newOutput = output
                        elif output == Epsilon:
                            newOutput = preOutput
                        else:
                            newOutput = preOutput + output

                        #newInput is a prefix of newOutput
                        if newOutput.startswith(newInput):
                            #newInput equals newOutput?
                            if newInput == newOutput:
                                newInput = newOutput = Epsilon
                            else:
                                newOutput = newOutput[len(newInput):]
                                newInput = Epsilon
                        elif newInput.startswith(newOutput):
                            #newInput equals newOutput?
                            if newInput == newOutput:
                                newInput = newOutput = Epsilon
                            else:
                                newInput = newInput[len(newOutput):]
                                newOutput = Epsilon
                        else:
                            if newInput != Epsilon and newOutput != Epsilon\
                               and newInput != newOutput:
                                return False

                        # If end is one of the final state and it's value
                        # not equal (Epsilon, Epsilon), return False
                        if end in self.Final and \
                           (newInput != Epsilon or newOutput != Epsilon):
                            return False

                        #check if end is in done dictionary
                        if end not in done.keys():

                            #Add state end to notOone for later operation
                            notDone.append(end)

                            #Set the value of state end in done dictionary
                            done[end] = (newInput, newOutput)
                        else:

                            #If end's value equals to svalue, then continue
                            if done[end] == (newInput, newOutput):
                                continue
                            else:
                                #One state cannot have two different value
                                return False

        #The transducer is functional, return True
        return True       

    def outputIntersect(self, other):
        """Conjunction of transducer and automaton: X & Y
           using output intersect operation.
        Arg:
            other: the automaton needs to be operated.
        @rtype: Transducer
        """

        #If automaton's type is incompatible, raise FAdoGeneralError
        if type(other) != NFA and type(other) != DFA:
            raise FAdoGeneralError("Incompatible objects")

        #Do output intersect operation
        def sN(a, s):
            """Find the index of state s.
            """

            try:
                i = a.stateName(s)
            except DFAstateUnknown:
                return None

            return i

        def kS(a, i):
            """Find the input label coming out of the state i
            """

            if i == None:
                return set()

            try:
                if type(a) == Transducer:
                    ks = []
                    for s in self.delta[i].keys():
                        for n in xrange(len(self.delta[i][s])):    
                            ks.append(self.delta[i][s][n][0])
                else:
                    ks = a.delta[i].keys()
            except KeyError:
                return set()

            return set(ks)

        def dealT(start, end, inputLabel, outputLabel):
            """Add transition to the new transducer instance.
            """

            if not (end in done or end in notDone):
                iN = new.addState(end)
                notDone.append(end)
            else:
                iN = new.stateName(end)

            new.addTransition(start, inputLabel, outputLabel, iN)

        #Initialize a new transducer instance
        new = Transducer()

        #Conjunct the transducer's output and automaton's sigma
        new.Output = set(self.Output.union(other.Sigma))

        #List to store states that have not been operated
        notDone = []

        #List to store states that have been operated
        done = []

        #Set (s1, s2) to be the initial start state of new transducer
        #s1 is the start state of transducer
        #s2 is the start state of automaton
        for s1 in [self.States[x] for x in self.Initial]:
            for s2 in [other.States[x] for x in other.Initial]:
                sname = (s1, s2)
                new.addState(sname)
                new.addInitial(new.stateName(sname))

                if (s1, s2) not in notDone:
                    notDone.append((s1, s2))

        #Some states in the notDone list
        while notDone:

            #Get the state needs to operate from the notDone list
            state = notDone.pop()

            #Store the state to done list
            done.append(state)

            (s1, s2) = state
            i = new.stateName(state)

            (i1, i2) = (sN(self, s1), sN(other, s2))
            #TODO, find the output label coming out of the transducer
            (k1, k2) = (kS(self, i1), kS(other, i2))

            #State i1 has the same output label with s2 coming out
            for k in k1.intersection(k2):
                for s in self.delta[i1].keys():
                    for n in xrange(len(self.delta[i1][s])):
                        if self.delta[i1][s][n][0] == k:
                            for destination in [(self.States[d1], other.States[d2])
                                                for d1 in self.delta[i1][s][n][1]\
                                                for d2 in other.delta[i2][k]]:

                                #Get the input label from transducer
                                inputLable = s

                                #Add transition to the new transducer instance
                                dealT(i, destination, inputLable, k)

            #State i1 has some output label that state i2 doesn't have
            for k in k1 - k2:
                for s in self.delta[i1].keys():
                    for n in xrange(len(self.delta[i1][s])):
                        if self.delta[i1][s][n][0] == k:
                            #Get the input label from transducer
                            inputLable = s

                            destination = list(self.delta[i1][s][n][1])[0]

                            #Add transition to the new transducer instance
                            dealT(i, (self.States[destination], EmptySet), inputLable, k)

            #State i2 has some output labels that state i1 doesn't have
            for k in k2 - k1:
                for n in other.delta[i2][k]:

                    #Add transition to the new transducer instance
                    dealT(i, (EmptySet, other.States[n]), Epsilon, k)

        #Set x to the new automata's final state
        for x in [(self.States[a], other.States[b])
                  for a in self.Final for b in other.Final]:
            if x in new.States:
                new.addFinal(new.stateName(x))

        return new

    def inverse(self):
        """Switch the input label with the output label.
        No initial or final state changed.
        @returns: Transducer with transitions switched.
        @rtype: Transducer
        """

        #Initialize a new transducer instance.
        new = Transducer()

        #Copy the states, final, initial, sigma and output set
        #to the new transducer instance.
        new.States = list(self.States)
        new.Final = set(self.Final)
        new.Initial = set(self.Initial)
        new.Sigma = set(self.Output)
        new.Output = set(self.Sigma)

        #Switch the input label with output label in the old
        #transducer and add transition to new instance.
        for s in self.delta.keys():
            for st1 in self.delta[s].keys():
                length = len(self.delta[s][st1])
                for n in xrange(length):
                    st2 = self.delta[s][st1][n][0]
                    d = list(self.delta[s][st1][n][1])[0]
                    new.addTransition(s, st2, st1, d)

        return new

    def reversal(self):
        """Returns a transducer that recognizes the reversal of the relation.
        @returns: Transducer recognizing reversal language
        @rtype: Transducer"""

        #Initialize a new transducer instance.
        new = Transducer()

        new.States = list(self.States)

        #Set the initial state in the old transducer to
        #the final state in the new instance.
        new.Final = set(self.Initial)

        #Set the final state in the old transducer to
        #the initial state in the new instance.
        new.Initial = set(self.Final)
        
        new.Sigma = set(self.Output)
        new.Output = set(self.Sigma)

        #Switch the input label with output label in the old
        #transducer and add transition to new instance.
        for s in self.delta.keys():
            for st1 in self.delta[s].keys():
                length = len(self.delta[s][st1])
                for n in xrange(length):
                    st2 = self.delta[s][st1][n][0]
                    d = list(self.delta[s][st1][n][1])[0]
                    new.addTransition(d, st2, st1, s)

        return new
     
    def epsilonP(self):
        """Whether this Transducer has epsilon-transitions"""
        
        if Epsilon in str(list(self.delta.itervalues())):
            return True
        else:
            return False

    def addEpsilonTransition(self):
        """Add a transition with epsilon input and output
        to every state in the transducer."""

        stateNum = len(self.States)
        
        for i in range(stateNum):
            self.addTransition(i,Epsilon,Epsilon,i)        

    def usefulStates(self, initial_states = None):
        """Set of states reacheable from the given initial state(s)
        that have a path to a final state.

        @param initial_states: set of sub-automaton's initial states
        (default: self.Initial)
        @type initial_states: iterable of integers
        @return: set of state indexes
        @rtype: set of integers"""
        if initial_states is None:
            if type(self) is Transducer:
                initial_states = self.Initial
            if type(self) is RealTimeTransducer:
                initial_states = set()
                for s in self.Initial.keys():
                    initial_states.add(self.stateName(s, True))
        useful = set([s for s in initial_states
                      if s in self.Final])

        stack = list(initial_states)
        preceding = {}

        for i in stack:
            preceding[i] = []

        while stack:
            state = stack.pop()
            if not state in self.delta:
                continue
            for symbol in self.delta[state]:
                length = len(self.delta[state][symbol])
                for index in range(length):
                    adjacent = list(self.delta[state][symbol][index][1])[0]
                    is_useful = adjacent in useful
                    if adjacent in self.Final or is_useful:
                        useful.add(state)
                        if not is_useful:
                            useful.add(adjacent)
                            preceding[adjacent] = []
                            stack.append(adjacent)
                        inpath_stack = [p for p in preceding[state]
                                        if not p in useful]
                        preceding[state] = []
                        while inpath_stack:
                            previous = inpath_stack.pop()
                            useful.add(previous)
                            inpath_stack += [p for p in preceding[previous]
                                             if not p in useful]
                            preceding[previous] = []
                        continue
                    if adjacent not in preceding:
                        preceding[adjacent] = [state]
                        stack.append(adjacent)
                    else:
                        preceding[adjacent].append(state)
        if not useful and self.Initial:
            useful.add(min(self.Initial))
        return useful
                    
    def deleteStates(self, del_states):
        """Delete given iterable collection of states from the
        automaton.

        @note: delta function will always be rebuilt, regardless of
        whether the states list to remove is a suffix, or a sublist,
        of the automaton's states list.

        @arg del_states: collection of integers representing states"""
        rename_map = {}
        new_delta = {}
        new_final = set()
        new_states = []

        for state in range(len(self.States)):
            if not state in del_states:
                rename_map[state] = len(new_states)
                new_states.append(self.States[state])

        for state in rename_map:
            if state in self.Final:
                new_final.add(rename_map[state])
            if state not in self.delta:
                continue
            if not len(self.delta[state]) == 0:
                new_delta[rename_map[state]] = {}
            for symbol in self.delta[state]:
                targetList = []
                length = len(self.delta[state][symbol])
                for index in range(length):
                    if rename_map.has_key(\
                        list(self.delta[state][symbol][index][1])[0]):
                        for i in range(len(new_states)):
                            if new_states[i] == self.States[list(
                                self.delta[state][symbol][index][1])[0]]:
                                newindex = i
                        targetList.append([self.delta[state][symbol][index][0],
                                           set([newindex])])
                if targetList:
                    new_delta[rename_map[state]][symbol] = targetList
                    
            if new_delta[rename_map[state]] == {}:
                del new_delta[rename_map[state]]

        if type(self) is Transducer:
            self.Initial = set(map(lambda x: rename_map.get(x, x),
                                   self.Initial))
        if type(self) is RealTimeTransducer:
            initial = {}
            for s in self.Initial.keys():
                if rename_map.has_key(self.stateName(s)):
                    initial[s] = self.Initial[s]
            self.Initial = initial

        self.States = new_states
        self.delta = new_delta
        self.Final = new_final

        #Discard useless labels in Sigma
        self.Sigma = set()
        self.Output = set()
        for s in self.delta.keys():
            for n in self.delta[s].keys():
                self.Sigma.add(n)
                for k in xrange(len(self.delta[s][n])):
                    if self.delta[s][n][k][0] != Epsilon:
                        self.Output.add(self.delta[s][n][k][0])

    def saveToFile(self, FileName, Mode = "w"):
        """ Saves a finite transducer definition to
        a file using the input format.
        @arg FileName: file name
        @type FileName: string
        @arg Mode: file mode
        @type Mode: string
        """
        
        try:
            f = open(FileName, Mode)

            f.write("@Transducer \n")

            #Write the start states
            f.write("Start States: ")
            for sf in self.Initial:
                f.write("%s " %self.States[sf])
            f.write("\n")

            #Write the final states
            f.write("Final States: ")
            for sf in self.Final:
                f.write("%s " %self.States[sf])
            f.write("\n")

            #Write every transitions in the delta
            for s in self.delta.keys():
                for a in self.delta[s].keys():
                    length = len(self.delta[s][a])
                    for i in range(length):
                        b = self.delta[s][a][i][0]
                        s1 = list(self.delta[s][a][i][1])[0]
                        
                        f.write("%s %s %s %s\n" %(self.States[s],
                                                  a, b, self.States[s1]))

        except IOError as ex:
            print("Error occured when saving to file: " + str(ex))

        finally:
            #Close the file
            f.close()

    def standardToNormalForm(self):
        """Translate a transducer in standard form into the one in normal form.
        @returns: Transducer in Normal Form.
        @rtype: Transducer"""

        #Initialize a new transducer instance.
        new = Transducer()

        #Set the state list, final, initial, sigma and output
        #of the old transducer to the new transducer instance.
        new.States = list(self.States)
        new.Final = set(self.Final)
        new.Initial = set(self.Initial)
        new.Sigma = set(self.Sigma)
        new.Output = set(self.Output)

        #For every transition that has non-Epsilon input
        #and output label, add a new state and two transitions
        for s in self.delta.keys():
            for st1 in self.delta[s].keys():
                length = len(self.delta[s][st1])
                for n in xrange(length):
                    st2 = self.delta[s][st1][n][0]
                    d = list(self.delta[s][st1][n][1])[0]

                    #If input label and output label are both not
                    #equal to Epsilon, we need to add a new state
                    #between the two states s and d
                    if st1 != Epsilon and st2 != Epsilon:

                        #New state name is "indexnumber" + "_new"
                        newstate = str(len(new.States) + 1) + "_new"

                        #Add to the states of transducer and get the index
                        newD = new.stateName(newstate, True)

                        #Add two transitions with epsilon labels
                        new.addTransition(s, st1, Epsilon, newD)
                        new.addTransition(newD, Epsilon, st2, d)

                    #If not, just add the transition to the new transducer
                    else:
                        new.addTransition(s, st1, st2, d)

        return new

    def generalToStandardForm(self):
        """Translate a transducer in general form into the one in standard form.
        @returns: Transducer in standard Form.
        @rtype: Transducer"""

        #Initialize a new transducer instance.
        new = Transducer()

        #Set the state list, final, initial, sigma and output
        #of the old transducer to the new transducer instance.
        new.States = list(self.States)
        new.Final = set(self.Final)
        new.Initial = set(self.Initial)

        #For every transition that has non-Epsilon input
        #and output label, add new states and transitions
        for s in self.delta.keys():
            for st1 in self.delta[s].keys():
                length = len(self.delta[s][st1])
                for n in xrange(length):
                    st2 = self.delta[s][st1][n][0]
                    d = list(self.delta[s][st1][n][1])[0]

                    #If input label is Epsilon and the length of output
                    #label bigger than 2, we need to add new state and
                    #new transition
                    if (st1 == Epsilon or len(st1) == 1) and len(st2) > 1 and st2 != Epsilon:

                        for label in xrange(len(st2)):

                            if st2[label] == " ":
                                break

                            #New state name is "indexnumber" + "_new"
                            newState = str(len(new.States) + 1) + "_new"
                            #Add new transition to the standard form transducer
                            if label == 0:
                                #add to the states of new transducer and get the index
                                newD = new.stateName(newState, True)
                                new.addTransition(s, st1, st2[label], newD)
                            elif label == (len(st2) - 1):
                                new.addTransition((len(new.States) - 1), Epsilon, st2[label], d)
                            else:
                                #Add to the states of new transducer and get the index
                                newD = new.stateName(newState, True)
                                new.addTransition((newD - 1), Epsilon, st2[label], newD)

                            #Add output label to the output alphabet (no space allowed)
                            new.addOutput(st2[label])
                    elif len(st1) > 1 and (st2 == Epsilon or len(st2) == 1) and st1 != Epsilon:

                        for label in xrange(len(st1)):
                            if st1[label] == " ":
                                break

                            newState = str(len(new.States) + 1) + "_new"
                            if label == 0:
                                newD = new.stateName(newState, True)
                                new.addTransition(s, st1[label], st2, newD)
                            elif label == (len(st1) - 1):
                                new.addTransition((len(new.States) - 1), st1[label], Epsilon, d)
                            else:
                                newD = new.stateName(newState, True)
                                new.addTransition((newD - 1), st1[label], Epsilon, newD)
                    elif len(st1) > 1 and len(st2) > 1 and st1 == st2 != Epsilon:
                        if len(st1) >= len(st2):
                            lenDiff = len(st1) - len(st2)
                            for label in xrange(len(st2)):
                                if st1[label] == " " or st2[label] == " ":
                                    break

                                newState = str(len(new.States) + 1) + "_new"
                                if label == 0:
                                    newD = new.stateName(newState, True)
                                    new.addTransition(s, st1[label], st2[label], newD)
                                elif label == len(st1) - 1 and label == len(st2) - 1:
                                    new.addTransition((len(new.States) - 1), st1[label], st2[label], d)
                                else:
                                    newD = new.stateName(newState, True)
                                    new.addTransition((newD - 1), st1[label], st2[label], newD)
                            for rest in xrange(lenDiff):
                                newState = str(len(new.States) + 1) + "_new"
                                if rest == (lenDiff - 1):
                                    new.addTransition((len(new.States) - 1),
                                                      st1[len(st2) + rest], Epsilon, d)
                                else:
                                    newD = new.stateName(newState, True)
                                    new.addTransition((newD - 1),
                                                      st1[len(st2) + rest], Epsilon, newD)
                        else:
                            lenDiff = len(st2) - len(st1)
                            for label in xrange(len(st1)):
                                newState = str(len(new.States) + 1) + "_new"
                                if label == 0:
                                    newD = new.stateName(newState, True)
                                    new.addTransition(s, st1[label], st2[label], newD)
                                else:
                                    newD = new.stateName(newState, True)
                                    new.addTransition((newD - 1), st1[label], st2[label], newD)
                            for rest in xrange(lenDiff):
                                newState = str(len(new.States) + 1) + "_new"
                                if rest == (lenDiff - 1):
                                    new.addTransition((len(new.States) - 1),
                                                      Epsilon, st2[len(st1) + rest], d)
                                else:
                                    newD = new.stateName(newState, True)
                                    new.addTransition((newD - 1),
                                                      Epsilon, st2[len(st1) + rest], newD)
                    else:
                        new.addTransition(s, st1, st2, d)

        return new

    def sequentialToPseudo(self):
        """Translate a sequential transducer to Pseudo-sequential transducer.
        @return: Pseudo-sequential transducer.
        @rtype: Transducer
        """

        #Initialize a new transducer instance.
        new = Transducer()

        #Set the state list, final, initial, sigma
        #of the old transducer to the new transducer instance.
        new.States = list(self.States)
        new.Final = set(self.Final)
        new.Initial = set(self.Initial)
        new.Sigma = set(self.Sigma)

        #For every transition that its output label is a word
        #whose length equals or bigger than 2, add new states
        #and transitions with Epsilon input
        for s in self.delta.keys():
            for st1 in self.delta[s].keys():
                length = len(self.delta[s][st1])
                for n in xrange(length):
                    #Get the output label
                    st2 = self.delta[s][st1][n][0]

                    if (st2 != Epsilon and len(st2) >= 2):
                        #Get the end state of this transition
                        endState = list(self.delta[s][st1][n][1])[0]

                        #Get every single symbol out of the output label
                        #and add new state and transition
                        for n in xrange(len(st2)):

                            if st2[n] == " ":
                                break;
                            
                            #New state name is "indexnumber" + "_new"
                            newState = str(len(new.States) + 1) + "_new"

                            #Add new transition to new Pseudo-sequential transducer
                            if n == 0:
                                #Add to the states of new transducer and get the index
                                newD = new.stateName(newState, True)
                                new.addTransition(s, st1, st2[n], newD)                                
                            elif n == (len(st2) - 1):
                                new.addTransition((len(new.States) - 1), Epsilon, st2[n], endState)
                            else:
                                #Add to the states of new transducer and get the index
                                newD = new.stateName(newState, True)                                
                                new.addTransition((newD - 1), Epsilon, st2[n], newD)

                            #Add output label to the output alphabet(no space allowed)
                            new.addOutput(st2[n])
                            
                    #If not, just add the transtion to the new transducer
                    else:
                        #Get the end state of this transition
                        endState = list(self.delta[s][st1][n][1])[0]
                        
                        new.addTransition(s, st1, st2, endState)

        return new

    def pseudoToSequential(self):
        """Translate a Pseudo-sequentail transducer to a sequential transducer
        @return: Sequential transducer
        @rtype: Transducer
        """

        #Initialize a new transducer instance
        new = Transducer()

        #Set the final, initial, sigma in the old Pseudo-sequential transducer
        #to the new sequential transducer instance
        new.Final = set(self.Final)
        new.Initial = set(self.Initial)
        new.Sigma = set(self.Sigma)

        #Iterate every transition in Pseudo-sequential transducer, add new states
        #output alphabet and transitions when necessary
        for s in self.delta.keys():
            for st1 in self.delta[s].keys():
                #Proceed non input-epsilon transitions
                if st1 != Epsilon:
                    for n in xrange(len(self.delta[s][st1])):
                        #Get the first output symbol
                        outputLabel = self.delta[s][st1][n][0]

                        #Get the end state of this transition
                        endState = list(self.delta[s][st1][n][1])[0]

                        #Find the epsilon path from endState and
                        #append the output label to outputLabel
                        while (endState in self.delta.keys() and
                               Epsilon in self.delta[endState].keys()):
                            
                            if outputLabel !=Epsilon:
                                outputLabel += self.delta[endState][Epsilon][0][0]
                            else:
                                outputLabel = self.delta[endState][Epsilon][0][0]
                                
                            #Get the new end state
                            endState = list(self.delta[endState][Epsilon][0][1])[0]
                            if endState in self.delta.keys():
                                continue
                            else:
                                break

                        startState = new.stateName(self.States[s], True)
                        endState = new.stateName(self.States[endState], True)
                        if outputLabel != Epsilon:
                            new.addOutput(outputLabel)
                        new.addTransition(startState, st1,
                                          outputLabel, endState)

        #Set initial state to sequential transducer
        initialList = []
        for s in self.Initial:
            initialList.append(new.stateName(self.States[s]))
        new.setInitial(initialList)
        
        #Set final state to sequential transducer
        finalList = []
        for s in self.Final:
            finalList.append(new.stateName(self.States[s]))
        new.setFinal(finalList)

        return new

    def createSIDChannel(self, n, sigmaSet):
        """Create a SID channel based on n and sigmaSet
        @arg n: integer indicating SID times of the channel
        @type n: integer
        @arg sigmaSet: a set of sigma to construct the channel
        @type sigmaSet: set
        @return: a transducer representing the SID channel
        @rtype: Transducer
        """

        #Initialize a new transducer instance
        new = Transducer()

        new.Sigma = set(sigmaSet)
        new.Output = set(sigmaSet)

        if n <= 0:
            return None

        for i in xrange(n):
            if i == 0:
                new.setInitial([i])

            startState = new.stateName(str(i), True)
            endState = new.stateName(str(i+1), True)

            for s in new.Sigma:
                new.addTransition(startState, s, s, startState)
                new.addTransition(startState, s, Epsilon, endState)
                new.addTransition(startState, Epsilon, s, endState)

                for s2 in new.Sigma:
                    new.addTransition(startState, s, s2, endState)

        # deal with the last state
        startState = new.stateName(new.States[n], True)
        
        for s in new.Sigma:
            new.addTransition(startState, s, s, startState)

        for i in new.States:
            new.Final.add(new.stateName(i))

        return new

    def functionalP(self):
        """Tests if sequential transducer is functional
        @return: True is functional, False is not functional
        @rtype: Boolean"""

        '''#If '+' or '*' exists in the output or initial set,
        #then this real time transducer is not functional 
        if '+' in str(self.Output) or '*' in str(self.Output):
            return False
        
        if '+' in str(self.Initial) or '*' in str(self.Initial):
            return False'''

        # Checking if there is epsilon input transition in this
        # transducer. If yes, add epsilon transitions to itself.
        try:
            for i in self.delta.keys():
                if Epsilon in self.delta[i].keys():
                    self.addEpsilonTransition()
                    break
        except Exception, ex:
            print(str(ex))
            
        #Construct the cross products of two same real time transducers.
        new = self.crossProductConstruction()

        def getCounterExample(NFA, path, state):
            """Get the counter example.
            """
            if state in NFA.Final:
                inputword = list(path)[0]
                outputword1 = list(path)[1]
                outputword2 = list(path)[2]
                return (inputword, outputword1, outputword2)
            else:
                notDone = set()
                notDone.add(state)
                done = {}
                done[state] = path
                while notDone:
                    state = notDone.pop()
                    value = done[state]
                    if state in NFA.delta.keys():
                        for n in NFA.delta[state].keys():
                            input = list(n)[0]
                            newString = re.sub(r'\(|\)|\s', '', list(n)[1])
                            x1 = newString.split(',')[0]
                            x2 = newString.split(',')[1]
                            
                            if input == Epsilon:
                                input = ""
                            if x1 == Epsilon:
                                x1 = ""
                            if x2 == Epsilon:
                                x2 = ""
                                
                            inputword = list(value)[0] + input
                            outputword1 = list(value)[1] + x1
                            outputword2 = list(value)[2] + x2                              
                            for s in NFA.delta[state][n]:
                                if s in NFA.Final:
                                    return (inputword, outputword1, outputword2)
                                elif s not in done.keys():
                                    notDone.add(s)
                                    done[s] = (inputword, outputword1, outputword2)
                                else:
                                    if done[s] == (inputword, outputword1, outputword2):
                                        continue
                                    else:
                                        done[s] == (inputword, outputword1, outputword2)

        new.trim()
        
        notDone = set()
        done = {}

        for s in new.Initial:
            notDone.add(s)

        #TODO: Check whether this is right.
        done[s] = (("", "", ""), Epsilon + "," + Epsilon)
        
        while notDone:
            state = notDone.pop()
            value = done[state]

            #Remove all the space and brackets in the value string
            pathValue = list(value)[0]
            stateValue = re.sub(r'\(|\)|\s', '', list(value)[1])

            if state in new.delta.keys():
                for n in new.delta[state].keys():

                    #Get the label value in the incoming transition.
                    #Split it into two labels.
                    y1 = stateValue.split(',')[0]
                    y2 = stateValue.split(',')[1]

                    #If labels are equal to Epsilon, just set the label
                    #to an empty string.
                    if y1 == Epsilon:
                        y1 = ""
                    if y2 == Epsilon:
                        y2 = ""

                    #Remove all the space and brackets in the (n) string
                    input = list(n)[0]
                    newString = re.sub(r'\(|\)|\s', '', list(n)[1])
                    
                    #Get the label value in the outgoing transition.
                    #Split it into two labels.
                    x1 = newString.split(',')[0]
                    x2 = newString.split(',')[1]

                    #If labels are equal to Epsilon, just set the label
                    #to an empty string.
                    if input == Epsilon:
                        input = ""
                    if x1 == Epsilon:
                        x1 = ""
                    if x2 == Epsilon:
                        x2 = ""

                    #(y1 + x1) is a prefix of (y2 + x2)
                    if (y2 + x2).startswith(y1 + x1):
                        for s in new.delta[state][n]:

                            #Is (y1 + x1) equals (y2 + x2)                    
                            if (y2 + x2) == (y1 + x1):
                                
                                #Value of state s is (Epsilon, Epsilon)
                                svalue = Epsilon + "," + Epsilon
                            else:
                                
                                #Value of state s is (Epsilon, label)
                                #label = (y2 + x2) slices (y1 + x1)
                                svalue = Epsilon + "," + \
                                         (y2 + x2)[len(y1 + x1):]

                            newPathValue = (list(pathValue)[0] + input,
                                            list(pathValue)[1] + x1,
                                            list(pathValue)[2] + x2)
                            #Has value of state s already been calculated? 
                            if s not in done.keys():

                                #Add state s to notDone for later operation   
                                notDone.add(s)

                                #Store the value of state s
                                done[s] = (newPathValue, svalue)
                            else:

                                #If s' value equals to svalue, then continue   
                                if list(done[s])[1] == svalue:
                                    done[s] = (newPathValue, svalue)
                                else:
                                    """counterExample = getCounterExample(new,
                                                                       newPathValue, s)"""
                                    counterExample = getCounterExample(new,
                                                                       list(done[s])[0], s)
                                    print(counterExample)
                                    #One state cannot have two different value 
                                    return False

                    #(y1 + x1) is a prefix of (y2 + x2)            
                    elif (y1 + x1).startswith(y2 + x2):
                        for s in new.delta[state][n]:

                            #Is (y1 + x1) equals (y2 + x2)                
                            if (y2 + x2) == (y1 + x1):

                                #Value of state s is (Epsilon, Epsilon)
                                svalue = Epsilon + "," + Epsilon
                            else:

                                #Value of state s is (label, Epsilon)
                                #label = (y1 + x1) slices (y2 + x2)
                                svalue = (y1 + x1)[len(y2 + x2):] + \
                                         "," + Epsilon

                            newPathValue = (list(pathValue)[0] + input,
                                            list(pathValue)[1] + x1,
                                            list(pathValue)[2] + x2)
                                
                            #Has value of state s already been calculated?
                            if s not in done.keys():

                                #Add state s to notDone for later operation   
                                notDone.add(s)

                                #Store the value of state s
                                done[s] = (newPathValue, svalue)
                            else:

                                #If s' value equals to svalue, then continue   
                                if list(done[s])[1] == svalue:
                                    done[s] = (newPathValue, svalue)
                                else:
                                    """counterExample = getCounterExample(new,
                                                                       newPathValue, s)"""
                                    counterExample = getCounterExample(new,
                                                                       list(done[s])[0], s)
                                    print(counterExample)
                                    #One state cannot have two different value 
                                    return False

                    else:
                        for s in new.delta[state][n]:
                            newPathValue = (list(pathValue)[0] + input,
                                                list(pathValue)[1] + x1,
                                                list(pathValue)[2] + x2)
                        #Store the value of state s
                            counterExample = getCounterExample(new,
                                                               newPathValue, s)
                            print(counterExample)
                            return False

        #If every final state does not have value:
        #""Epsilon, Epsilon", then return False
        for s in new.Final:
            if list(done[s])[1] != Epsilon + "," + Epsilon:
                counterExample = getCounterExample(new, list(done[s])[0], s)
                print(counterExample)
                return False

        return True

    def crossProductConstruction(self):
        """Cross product construction of two sequential transuders.
        """

        #If type of this fa is not real time transducer, raise error
        if type(self) != Transducer:
            #TODO: Check this error
            raise FAdoGeneralError("Incompatible objects")

        #TODO: check whether it is necessary
        other = copy.copy(self)

        #Calculating the cross product of two same real time transducers.
        new = self.crossProduct(other)

        #Add x to the final state in the new nfa.
        for x in [(self.States[a], other.States[b])
                  for a in self.Final for b in other.Final]:

            if x in new.States:
                new.addFinal(new.stateName(x))

        #Make this new nfa trim.
        new.trim()

        return new

    def crossProduct(self, other):
        """Conjuction of sequential transducers.
        @arg other: the right hand operand
        @type other: Transducer
        @rtype:NFA
        """
        def sN(a, s):
            """Find the index of state s.
            """
            
            try:
                i = a.stateName(s)
            except DFAstateUnknown:
                return None
            
            return i
        
        def kS(a, i):
            """Find the input label coming out of state i.
            """
            
            if i == None:
                return set()
            
            try:
                ks = a.delta[i].keys()
            except KeyError:
                return set()
            
            return set(ks)
        
        def dealT(srcI, dest, symb):
            """Add transition to the new transducer instance.
            """
            
            if not (dest in done or dest in notDone):
                iN = new.addState(dest)
                notDone.append(dest)
            else:
                iN = new.stateName(dest)

            new.addTransition(srcI, symb, iN)

        #Initialize a new NFA instance
        new = NFA()

        #List to store states that have not been operated
        notDone = []

        #List to store states that have been operated
        done = []

        #Set (s1, s2) to be the initial start state of new transducer
        #s1 is the start state of transudcer
        #s2 is the start state of transudcer        
        for s1 in [self.States[x] for x in self.Initial]:
            for s2 in [other.States[x] for x in other.Initial]:
                sname = (s1, s2)
                new.addState(sname)
                new.addInitial(new.stateName(sname))
                
                if (s1, s2) not in notDone:
                    notDone.append((s1, s2))

        #Some states in the notDone list
        while notDone:

            #Get the state needs to operate from the notDone list            
            state = notDone.pop()

            #Store the state to done list            
            done.append(state)
            
            (s1, s2) = state
            i = new.stateName(state)
            
            (i1, i2) = (sN(self, s1), sN(other, s2))
            (k1, k2) = (kS(self, i1), kS(other, i2))

            #State i1 and i2 have the same input label coming out from them
            for k in k1.intersection(k2):
                for n in xrange(len(self.delta[i1][k])):
                    for m in xrange(len(other.delta[i2][k])):

                        #Get the end state of this transition         
                        d = (self.States[list(self.delta[i1][k][n][1])[0]],
                             self.States[list(other.delta[i2][k][m][1])[0]])

                        #Get the label of this transition               
                        lable = self.delta[i1][k][n][0] + \
                                ',' + other.delta[i2][k][m][0]

                        #Add transition to the new NFA instance                
                        dealT(i, d, lable)

            #State i1 has some input labels that state i2 doesn't have         
            for k in k1 - k2:
                for n in xrange(len(self.delta[i1][k])):

                    #Get the label of the transition                    
                    lable = self.delta[i1][k][n][0] + ',' + Epsilon

                    #Get the end state of the transition                    
                    d = list(self.delta[i1][k][n][1])[0]

                    #Add transition to the new NFA isntance                    
                    dealT(i, (self.States[d], EmptySet), lable)

            #State i2 has some input labels that state i1 doesn't have        
            for k in k2 - k1:
                for n in xrange(len(other.delta[i2][k])):

                    #Get the label of the transition                    
                    lable = Epsilon + ',' + other.delta[i2][k][n][0]

                    #Get the end state of the transition
                    d = list(other.delta[i2][k][n][1])[0]

                    #Add transition to the new NFA isntance
                    dealT(i, (EmptySet, other.States[d]), lable)
                       
        return new

class RealTimeTransducer(Transducer):
    """Base class for Real Time Transducer.
    This is just a container for some common methods."""
    
    def __init__(self):
        """Initialize the transducer."""
        
        Transducer.__init__(self)

        #Set Initial to be a dictionary        
        self.Initial = {}        
    
    def __repr__(self):
        """Return a string adding type 'RealTimeTransducer'
        in front of the representation"""
        
        return 'RealTimeTransducer(%s)' % self.__str__()

    def simpleFunctionalP(self):
        """ Tests if realtime transducer is functional.
        The input label and output label of this kind of transducer
        just has one symbol from alphabet.
        @return: True is functional. False is not functional
        @rtype: Boolean"""

        #Construct the cross products of two same real time transducers.
        try:
            new = self.crossProductConstruction()
            #TODO: Check this error
        except FAdoGeneralError as ex:
            print(str(ex))

        #If two labels in the transition are not equal to each other,
        #then return False
        for n in new.delta.keys():
            for label in new.delta[n].keys():
                stringlist = label.split(",")
                if stringlist[0] != stringlist[1]:
                    return False

        return True

    def functionalP(self):
        """Tests if realtime transducer is functional
        @return: True is functional, False is not functional
        @rtype: Boolean"""

        #If '+' or '*' exists in the output or initial set,
        #then this real time transducer is not functional 
        if '+' in str(self.Output) or '*' in str(self.Output):
            return False
        
        if '+' in str(self.Initial) or '*' in str(self.Initial):
            return False

        #Construct the cross products of two same real time transducers.
        new = self.crossProductConstruction()
        
        notDone = set()
        done = {}

        for s in new.Initial:
            notDone.add(s)

        #TODO: Check whether this is right.
        done[s] = Epsilon + "," + Epsilon
        
        while notDone:
            state = notDone.pop()
            value = done[state]

            #Remove all the space and brackets in the value string
            value = re.sub(r'\(|\)|\s', '', value)

            if state in new.delta.keys():
                for n in new.delta[state].keys():

                    #Get the label value in the incoming transition.
                    #Split it into two labels.
                    y1 = value.split(',')[0]
                    y2 = value.split(',')[1]

                    #If labels are equal to Epsilon, just set the label
                    #to an empty string.
                    if y1 == Epsilon:
                        y1 = ""
                    if y2 == Epsilon:
                        y2 = ""

                    #Remove all the space and brackets in the (n) string
                    newString = re.sub(r'\(|\)|\s', '', n)
                    
                    #Get the label value in the outgoing transition.
                    #Split it into two labels.
                    x1 = newString.split(',')[0]
                    x2 = newString.split(',')[1]

                    #If labels are equal to Epsilon, just set the label
                    #to an empty string.
                    if x1 == Epsilon:
                        x1 = ""
                    if x2 == Epsilon:
                        x2 = ""

                    #(y1 + x1) is a prefix of (y2 + x2)
                    if (y2 + x2).startswith(y1 + x1):
                        for s in new.delta[state][n]:

                            #Is (y1 + x1) equals (y2 + x2)                    
                            if (y2 + x2) == (y1 + x1):
                                
                                #Value of state s is (Epsilon, Epsilon)
                                svalue = Epsilon + "," + Epsilon
                            else:
                                
                                #Value of state s is (Epsilon, label)
                                #label = (y2 + x2) slices (y1 + x1)
                                svalue = Epsilon + "," + \
                                         (y2 + x2)[len(y1 + x1):]

                            #Has value of state s already been calculated? 
                            if s not in done.keys():

                                #Add state s to notDone for later operation   
                                notDone.add(s)

                                #Store the value of state s           
                                done[s] = svalue
                            else:

                                #If s' value equals to svalue, then continue   
                                if done[s] == svalue:
                                    continue
                                else:

                                    #One state cannot have two different value 
                                    return False

                    #(y1 + x1) is a prefix of (y2 + x2)            
                    elif (y1 + x1).startswith(y2 + x2):
                        for s in new.delta[state][n]:

                            #Is (y1 + x1) equals (y2 + x2)                
                            if (y2 + x2) == (y1 + x1):

                                #Value of state s is (Epsilon, Epsilon)
                                svalue = Epsilon + "," + Epsilon
                            else:

                                #Value of state s is (label, Epsilon)
                                #label = (y1 + x1) slices (y2 + x2)
                                svalue = (y1 + x1)[len(y2 + x2):] + \
                                         "," + Epsilon

                            #Has value of state s already been calculated?
                            if s not in done.keys():

                                #Add state s to notDone for later operation   
                                notDone.add(s)

                                #Store the value of state s           
                                done[s] = svalue
                            else:

                                #If s' value equals to svalue, then continue   
                                if done[s] == svalue:
                                    continue
                                else:

                                    #One state cannot have two different value 
                                    return False

                    else:
                        return False

        #If every final state does not have value:
        #""Epsilon, Epsilon", then return False
        for s in new.Final:
            if done[s] != Epsilon + "," + Epsilon:
                return False

        return True

    def crossProductConstruction(self):
        """Cross product construction of two realtime transuders.
        """

        #If type of this fa is not real time transducer, raise error
        if type(self) != RealTimeTransducer:
            #TODO: Check this error
            raise FAdoGeneralError("Incompatible objects")

        #TODO: check whether it is necessary
        other = copy.copy(self)

        #Calculating the cross product of two same real time transducers.
        new = self.crossProduct(other)

        #Add x to the final state in the new nfa.
        for x in [(self.States[a], other.States[b])
                  for a in self.Final for b in other.Final]:

            if x in new.States:
                new.addFinal(new.stateName(x))

        #Make this new nfa trim.
        new.trim()

        return new

    def crossProduct(self, other):
        """Conjuction of real time transducers.
        @arg other: the right hand operand
        @type other: RealTimeTransducer
        @rtype:NFA
        """
        def sN(a, s):
            """Find the index of state s.
            """
            
            try:
                i = a.stateName(s)
            except DFAstateUnknown:
                return None
            
            return i
        
        def kS(a, i):
            """Find the input label coming out of state i.
            """
            
            if i == None:
                return set()
            
            try:
                ks = a.delta[i].keys()
            except KeyError:
                return set()
            
            return set(ks)
        
        def dealT(srcI, dest, symb):
            """Add transition to the new transducer instance.
            """
            
            if not (dest in done or dest in notDone):
                iN = new.addState(dest)
                notDone.append(dest)
            else:
                iN = new.stateName(dest)

            new.addTransition(srcI, symb, iN)

        #Initialize a new NFA instance
        new = NFA()

        #List to store states that have not been operated
        notDone = []

        #List to store states that have been operated
        done = []

        #Set (s1, s2) to be the initial start state of new transducer
        #s1 is the start state of transudcer
        #s2 is the start state of automata        
        for s1 in self.Initial.keys():
            for s2 in other.Initial.keys():
                sname = (s1, s2)
                new.addState(sname)
                
                if (s1, s2) not in notDone:
                    notDone.append((s1, s2))

        #Some states in the notDone list
        while notDone:

            #Get the state needs to operate from the notDone list            
            state = notDone.pop()

            #Store the state to done list            
            done.append(state)
            
            (s1, s2) = state
            i = new.stateName(state)
            
            (i1, i2) = (sN(self, s1), sN(other, s2))
            (k1, k2) = (kS(self, i1), kS(other, i2))

            #State i1 and i2 have the same input label coming out from them
            for k in k1.intersection(k2):
                for n in xrange(len(self.delta[i1][k])):
                    for m in xrange(len(other.delta[i2][k])):

                        #Get the end state of this transition         
                        d = (self.States[list(self.delta[i1][k][n][1])[0]],
                             self.States[list(other.delta[i2][k][m][1])[0]])

                        #Get the label of this transition               
                        lable = self.delta[i1][k][n][0] + \
                                ',' + other.delta[i2][k][m][0]

                        #Add transition to the new NFA instance                
                        dealT(i, d, lable)

            #State i1 has some input labels that state i2 doesn't have         
            for k in k1 - k2:
                for n in xrange(len(self.delta[i1][k])):

                    #Get the label of the transition                    
                    lable = self.delta[i1][k][n][0] + ',' + Epsilon

                    #Get the end state of the transition                    
                    d = list(self.delta[i1][k][n][1])[0]

                    #Add transition to the new NFA isntance                    
                    dealT(i, (self.States[d], EmptySet), lable)

            #State i2 has some input labels that state i1 doesn't have        
            for k in k2 - k1:
                for n in xrange(len(other.delta[i2][k])):

                    #Get the label of the transition                    
                    lable = Epsilon + ',' + other.delta[i2][k][n][0]

                    #Get the end state of the transition
                    d = list(other.delta[i2][k][n][1])[0]

                    #Add transition to the new NFA isntance
                    dealT(i, (EmptySet, other.States[d]), lable)

        #Set a (EmptySet, EmptySet) initial state of the new NFA instance       
        newInitial = new.stateName((EmptySet, EmptySet), True)
        new.setInitial([newInitial])

        #Add transitions from the (EmptySet, EmptySet) to every old initial
        #state in the new NFA instance
        for s1 in self.Initial.keys():
            for s2 in other.Initial.keys():
                lable = self.Initial[s1] + ',' + self.Initial[s2]
                new.addTransition(new.stateName((EmptySet, EmptySet)),
                                  lable, new.stateName((s1, s2)))
                       
        return new        

    def saveToFile(self, FileName, Mode = "w"):
        """ Saves a finite real-time transducer
        definition to a file using the input format
        @arg FileName: file name
        @type FileName: string
        @arg Mode: file mode
        @type Mode: string"""
        
        try:
            f = open(FileName, Mode)

            f.write("@Real-time Transducer \n")

            #Write the start state and its initial output
            f.write("Start States: ")
            for sf in self.Initial.keys():
                f.write("%s:%s " %(sf, self.Initial[sf]))
            f.write("\n")

            #Write the final states
            f.write("Final States: ")
            for sf in self.Final:
                f.write("%s " %self.States[sf])
            f.write("\n")

            #Write every transition in the delta
            for s in self.delta.keys():
                for a in self.delta[s].keys():
                    length = len(self.delta[s][a])
                    for i in range(length):
                        b = self.delta[s][a][i][0]
                        s1 = list(self.delta[s][a][i][1])[0]
                        
                        f.write("%s %s %s %s\n" %(self.States[s],
                                                  a, b, self.States[s1]))
                        
        except IOError as ex:
            print("Error occured when saving to file: " + str(ex))
        
        finally:
            #Close the file
            f.close()

