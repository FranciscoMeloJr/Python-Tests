#!/usr/bin/python
# coding=utf-8

# =====================================================
#
# This script will read a transducer description and
# then convert this transducer to a real-time
# transducer. Then it will decide whether this real-time
# transducer is functional or not.
#
# =====================================================

from cfg import *
from common import *
from fa import *
from reex import *
from unionFind import *

if __name__ == "__main__":

    # Load input file
    inputfile = "functionality-test1.txt"
    Trans = readFromFile(inputfile)

    print("The input transducer is: ")
    print(Trans[0])

    # Convert it to transducer in normal form    
    normalTrans = Trans[0].toNormalForm()

    # Convert transducer in normal form to real-time transducer
    realT = normalTrans.toRealTimeREType()

    print("The equivalent real-time transducer is: ")

    # Make the real-time transducer trim
    realT.trim()
    print(realT)
    
    # Decide whether this real-time transducer is functional.
    Functionality = realT.simpleFunctionalP()
    print("Is this transducer functional?")
    print(Functionality)