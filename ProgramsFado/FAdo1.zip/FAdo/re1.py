# -*- coding: utf-8 -*-
"""Regular expressions manipulation
@author: Rogério Reis & Nelma Moreira

This is part of U{FAdo project <http://www.ncc.up.pt/FAdo>}.

Regular expression classes and manipulation

@copyright: 1999-2009 Rogério Reis & Nelma Moreira {rvr,nam}@ncc.up.pt

Contributions by
 - Marco Almeida <mfa@ncc.up.pt>
 - Hugo Gouveia <gugo@ncc.up.pt>

B{Naming convention:} methods suffixed by P have boolean return.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA."""

__all__ = ["regexp", "disj", "concat", "star", "position", "epsilon", "emptyset",
           "EpsilonConst", "EmptySetConst", "str2regexp", "ParseReg", "ParseReg1", "ParseReg2"]

from collections import deque

from common import  *
import fa
from yappy.parser import *
from unionFind import UnionFind

class regexp(object):
    """Base class for regular expressions.

    Used directly to represent a symbol. The type of the symbol is
    arbitrary."""
    def __init__(self, val):
        """Constructor of a regular expression symbol.
        @param val: the actual symbol"""
        self.val = 'x'
        self.alphalen = 1

    def __repr__(self):
        """Representation of the regular expression's syntactical
        tree."""
        return "regexp(%s)" % repr(self.val)

    def __str__(self):
        """String representation of the regular expression."""
        return str(self.val)

    def alphabeticLength(self):
        """Number of occurrences of alphabet symbols in the regular
        expression.

        @attention: Doesn't include the empty word.

        @rtype: integer"""
        return self.alphalen
    def reduced(self):
        return self

class epsilon(regexp):
    """Class that represents the empty word."""
    def __init__(self):
        self.val = 'e'
        self.alphalen = 0

    def __repr__(self):
        return "epsilon()"

    def __str__(self):
        return Epsilon

class emptyset(regexp):
    """Class that represents the empty set."""
    def __init__(self):
        self.val = 's'
        self.alphalen = 0

    def __repr__(self):
        return "emptyset()"

    def __str__(self):
        return EmptySet

class disj(regexp):
    """Class for disjuction operation on regular expressions."""
    def __init__(self, exp1, exp2):
        self.val = '+'
        self.alphalen = exp1.alphalen + exp2.alphalen
        
    def __str__(self):
        return "disj of length %d" % self.alphalen
    
    def __repr__(self):
        return "(+, %d)" % self.alphalen

class star(regexp):
    """Class for iteration operation (aka Kleene star, or Kleene
    closure) on regular expressions."""
    def __init__(self, exp):
        self.val = '*'
        self.alphalen = exp.alphalen

    def __str__(self):
        return "star of length %d" % self.alphalen

    def __repr__(self):
        return "(*, %d)" % self.alphalen

class concat(regexp):
    """Class for catenation operation on regular expressions."""
    def __init__(self, exp1, exp2):
        if exp1.val == 's' or exp2.val == 's':
            self.val = 's'
            self.alphalen = 0
        else:
            self.val = '.'
            self.alphalen = exp1.alphalen + exp2.alphalen

    def __str__(self):
        return "concat of length %d" % self.alphalen

    def __repr__(self):
        return "(., %d)" % self.alphalen

class position(regexp):
    pass

EpsilonConst = epsilon()
EmptySetConst = emptyset()

class ParseReg1(Yappy):
    """ """
    def __init__(self,no_table=0,table ='tablereg'):
        """  """
        grammar = [("r",["r","|","c"],self.OrSemRule),
                   ("r",["c"],self.DefaultSemRule),
                   ("c",["c","s"],self.ConcatSemRule),
                   ("c",["s"],self.DefaultSemRule),
                   ("s",["s","*"],self.StarSemRule),
                   ("s",["f"],self.DefaultSemRule),
                   ("f",["b"],self.DefaultSemRule),
                   ("f",["(","r",")"],self.ParSemRule),
                   ("b",["id"],self.BaseSemRule),
                   ("b",[EmptySet],self.BaseSemRule),
                   ("b",[Epsilon],self.BaseSemRule)]
        tokenize = [("\s+", ""),
                    (Epsilon,lambda x: (x,x)),
                    (EmptySet,lambda x: (x,x)),
                    ("[A-Za-z0-9]",lambda x: ("id",x)),
                    ("\|",lambda x: (x,x)),
                    ("\+",lambda x: ("|",x)),
                    ("\*",lambda x: (x,x)),
                    ("\(|\)",lambda x: (x,x)) ]
        Yappy.__init__(self,tokenize,grammar,table,no_table)

    def DefaultSemRule(self,lst,context=None):
        return lst[0]

    def BaseSemRule(self,lst,context=None):
        if lst[0] == Epsilon:
            return EpsilonConst
        if lst[0] == EmptySet:
            return EmptySetConst
        return regexp(lst[0])

    def ParSemRule(self,lst,context=None):
        return  lst[1]

    def OrSemRule(self,lst,context=None):
        return disj(lst[0],lst[2])

    def ConcatSemRule(self,lst,context=None):
        return concat(lst[0],lst[1])

    def StarSemRule(self,lst,context=None):
        return star(lst[0])

    def DoPrint(self,lst,context=None):
        print lst[0]
        return lst[0]

class ParseReg(ParseReg1):
     def __init__(self,no_table=0, table='tableambreg'):
        """A parser for regular expressions with ambiguous rules: not working  """

        grammar = """
        reg -> reg + reg {{ self.OrSemRule }} |
               reg reg {{ self.ConcatSemRule // 200 left }} |
               reg * {{ self.StarSemRule }} |
               ( reg ) {{self.ParSemRule }} |
               id {{ self.BaseSemRule }};
        """

        tokenize = [(Epsilon,lambda x: ("id",x)),
                    (EmptySet,lambda x: ("id",x)),
                    ("[A-Za-z0-9]",lambda x: ("id",x)),
                    ("[+|]",lambda x: ("+",x),("+",100,'left')),
                    ("[*]",lambda x: (x,x),("*",300,'left')),
                    ("\(|\)",lambda x: (x,x)) ]

        Yappy.__init__(self,tokenize,grammar,table,no_table)

class ParseReg2(ParseReg1):
     def __init__(self,no_table=0, table='tableambreg2'):
         grammar = """
        reg -> reg + reg {{ self.OrSemRule}}|
               reg reg {{ self.ConcatSemRule // 200 left }} |
               reg * {{ self.StarSemRule }} |
               ( reg ) {{self.ParSemRule}} |
               id {{ self.BaseSemRule }} ;
        """
         tokenize = [("\s+",""),
                     (Epsilon,lambda x: ("id",x),("id",400,'left')),
                     (EmptySet,lambda x: ("id",x),("id",400,'left')),
                    ("[A-Za-z0-9]",lambda x: ("id",x),("id",400,'left')),
                    ("[+|]",lambda x: ("+",x),("+",100,'left')),
                    ("[*]",lambda x: (x,x),("*",300,'left')),
                    ("\(|\)",lambda x: (x,x)) ]

         Yappy.__init__(self,tokenize,grammar,table,no_table)

def str2regexp(s, parser=ParseReg1):
    """ Reads a regexp from string. """
    s = re.sub("\s+", "", s)
    d = parser()
    try:
        return d.input(s)
    except LRParserError:
        raise regexpInvalid(s)
