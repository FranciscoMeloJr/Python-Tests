#!/usr/bin/python
# coding=utf-8

# =====================================================
#
# This script will read a transducer description and an
# NFA description from a txt file and then decide
# whether the language recognized by the NFA is
# Error-Detection to the transducer.
#
# =====================================================

from cfg import *
from common import *
from fa import *
from reex import *
from unionFind import *

if __name__ == "__main__":

    # Load input file
    # The transducer read from the file should be
    # sequential
    inputfile = "Sequential-ErrorCorrection-test2.txt"
    FA = readFromFile(inputfile)

    print("The input transducer is: ")
    print(FA[0])
    
    print("The language recoginzed by the NFA is: ")
    print(FA[1].regexpSE())

    # Convert sequential transducer to Pseudo-sequential transducer
    result = FA[0].sequentialToPseudo()

    # Make Pseudo-sequential transducer trim
    result.trim()

    # Do output intersection of transducer and automaton
    try:
        for i in result.delta.keys():
            for n in result.delta[i].keys():
                if Epsilon in str(result.delta[i][n]):
                    FA[1].addEpsilonTransition()
                break
            break
        result = result.outputIntersect(FA[1])
    except FAdoGenralError, ex:
        print(str(ex))

    # Make the result transducer trim    
    result.trim()

    print("trim: ", result)

    # Convert Pseudo-sequential transducer to sequential transducer
    finalResult = result.pseudoToSequential()

    print("The transducer to functional test is: ", finalResult)

    if (len(finalResult.Final) != 0) or (len(finalResult.delta) != 0):

        # Make the final transducer trim
        finalResult.trim()

        print("The sequential transducer after trim operation is:",\
                  finalResult)

        # Decide whether this real-time transducer is functional.
        # While True is functional, False is not functional.
        Functionality = finalResult.functionalP()
        print(Functionality)
    else:
        print("True")
