#!/usr/bin/python
# coding=utf-8

# =====================================================
#
# This script will read a transducer description and an
# NFA description from a txt file and then decide
# whether the language recognized by the NFA is
# Error-Correction to the transducer.
#
# =====================================================

from cfg import *
from common import *
from fa import *
from reex import *
from unionFind import *

if __name__ == "__main__":

    # Load input file
    inputfile = "Sequential-ErrorDetection-test7.txt"
    FA = readFromFile(inputfile)

    print("The input language is: ")
    print(FA[1].regexpSE())

    channel = Transducer()
    channel = channel.createSIDChannel(2, FA[1].Sigma)

    print(channel)

'''
    # Diameter of langauge A
    diameter = len(FA[0].States) + 1

    # Do a binary search to compute edit distance of language A
    # using Error-Detection principle
    while n < diameter


    #Conjuction of transducer and automaton.
    try:
        for i in FA[0].delta.keys():
            if Epsilon in FA[0].delta[i].keys():
                FA[1].addEpsilonTransition()
            break
        
        newFa = FA[0].__and__(FA[1])
    except Exception, ex:
        print(str(ex))

    print(newFa)
    #Make the newFa trim.
    newFa.trim()

    print(newFa)    

    #Make the newFa inverse
    newFa = newFa.inverse()

    newFa.trim()
    
    print("trim:", newFa)    

    if (len(newFa.Final) != 0) or (len(newFa.delta) != 0):
        # Convert newFa to a transducer in normal form
        normalTrans = newFa.toNormalForm()

        # Convert normalTrans to real-time transducer
        realT = normalTrans.toRealTimeREType()

        # Make the realT transducer trim
        realT.trim()

        print("The equivalent real-time transducer after trim operation is:",\
                  realT)

        # Decide whether this real-time transducer is functional.
        # While True is functional, False is not functional.
        Functionality = realT.functionalP()
        print(Functionality)
    else:
        print("True")
    '''