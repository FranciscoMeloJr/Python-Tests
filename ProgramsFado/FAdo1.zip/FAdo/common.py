# -*- coding: utf-8 -*-
"""Common definitions for FAdo files
@author: Rogério Reis & Nelma Moreira

This is part of FAdo project http://www.ncc.up.pt/FAdo

Copyright (C) 1999-2009 Rogério Reis & Nelma Moreira {rvr,nam}@ncc.up.pt

Contributions by 
 - Marco Almeida <mfa@ncc.up.pt>
 - Hugo Gouveia <gugo@ncc.up.pt>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA."""

FAdoVersion = "0.3.1"

class fnhException(Exception):
    pass
    #def __init__(self,*args):
    #    self.args = args


class NotImplemented(fnhException):
    pass


class NonPlanar(fnhException):
    pass

class VertexNotInGraph(fnhException):
    pass

class FAException(fnhException):
    pass

class DFAerror(fnhException):
    pass

class PDAerror(fnhException):
    pass

class CFGerror(fnhException):
    pass

class CFGgrammarError(CFGerror):
    def __init__(self,rule):
        self.rule = rule
    def __str__(self):
        return "Error in rule %s"%(self.rule)

class CFGterminalError(CFGerror):
    def __init__(self,size):
        self.size = size
    def __str__(self):
        return "To many alphabetic symbols: %s"%(self.size)


class DFAstateRepeated(DFAerror):
    def __init__(self,number):
        self.number = number
    def __str__(self):
        return "State  number %s repeated"%(self.number)
    
class DFASyntaticError(DFAerror):
    def __init__(self,line):
        self.line = line


class DFAstateUnknown(DFAerror):
    def __init__(self,stidx):
        self.stidx = stidx
    def __str__(self):
        return "State  %s unknown"%(self.stidx)


class DFAnotNFA(DFAerror):
    def __init__(self,msg):
        self.message =  msg
    def __str__(self):
        return "Not a DFA %s"%(self.message)

class DFAepsilonRedefinition(DFAerror):
    pass

class DFAsymbolUnknown(DFAerror):
    def __init__(self,sym):
        self.symbol = sym
    def __str__(self):
        return "Symbol %s is unknown"%(self.symbol)

class DFAstopped(DFAerror):
    pass

class DFAFileError(DFAerror):
    def __init(self,name):
        self.filename = name
    def __str__(self):
        return "Error in file: %s"%(self.filename)

class DFAFound(DFAerror):
    def __init__(self,word):
        self.word = word[:]
    def __str__(self):
        return "Found: $s"%(self.word)

class DFAEmptyDFA(DFAerror):
    def __str__(self):
        return "Dfa is empty"

class DFAequivalent(DFAerror):
    def __str__(self):
        return "Dfa are equivalent"

class DFAnotComplete(DFAerror):
    def __str__(self):
        return "Dfa is nor complete"


class DFAinputError(DFAerror):
    def __init__(self,word):
        self.word = word
    def __str__(self):
        return "Input error: %s"%(self.word)

class DFAmarkedError(DFAerror):
    def __init__(self,sym):
        self.sym =  sym      
    def __str__(self):
        return "Symbol not marked %s" % str(self.sym)
    
class regexpInvalid(DFAerror):
    def __init__(self,word):
        self.word = word
        self.message = 'Error in regexp %s' %word
    def __str__(self):
        return "%s" % (self.message)  

class GraphError(fnhException):
    def __init__(self,message):
        self.message = message
    def __str__(self):
        return "%s" % (self.message)  

class PDAsymbolUnknown(PDAerror):
     def __init__(self,symb):
        self.symb = symb
     def __str__(self):
        return "Unknown stack symbol %s" % (self.symb)  
   
class PDAsymbolUnknown(PDAerror):
     def __init__(self,symb):
        self.symb = symb
        
EmptySet = "@empty_set"
Epsilon = "@epsilon"

DEBUG = False

TYPE_DISJ = "disj"
TYPE_CONC = "conc"
TYPE_STAR = "star"
TYPE_SYMB = "sym"
TYPE_EWRD = "ewrd"
TYPE_ESET = "eset"

def debug(string, level=0):
    print "%s%s" % ("".join(["\t" for i in xrange(level)]), string)

def memoize(cls, method_name):
    """Memoizes a given method result on instances of given class.

    Given method should have no side effects. Results are stored as
    instance attributes --- given parameters are disregarded.

    @note: original method is stored as <cls>.memoize_<method_name>_original
    @note: values are stored as <instance>.memoized_<method_name>
    @attention: all instances in all threads will be affected
    """
    saved_name = "memoize_"+method_name+"_original"
    if hasattr(cls, saved_name):
        return False
    attr_name = "memoized_"+method_name
    method = getattr(cls, method_name)
    setattr(cls, saved_name, method)
    if not hasattr(cls,"memoized_instances"):
        cls.memoized_instances = {}
    inst_list = []
    cls.memoized_instances[method_name] = inst_list
    def memo(self, *param):
        try:
            return getattr(self, attr_name)
        except AttributeError:
            value = method(self, *param)
            setattr(self, attr_name, value)
            inst_list.append(self)
            return value
    memo.__name__ = method_name
    setattr(cls, method_name, memo)
    return True

def dememoize(cls, method_name):
    """Restore method of given class from memoized state. Stored
    attributes will be removed."""
    saved_name = "memoize_"+method_name+"_original"
    if not hasattr(cls, saved_name):
        return False
    method = getattr(cls, saved_name)
    delattr(cls, saved_name)
    setattr(cls, method_name, method)
    for instance in cls.memoized_instances[method_name]:
        delattr(instance, "memoized_"+method_name)
    del cls.memoized_instances[method_name]
    if not cls.memoized_instances:
        del cls.memoized_instances
    return True

try:
    from itertools import product as cartesianProduct
except ImportError:
    def cartesianProduct(x, y):
        return [(a,b) for a in x for b in y]
