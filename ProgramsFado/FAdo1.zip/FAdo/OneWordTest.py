#!/usr/bin/python
# coding=utf-8

# =====================================================
#
# This script will read a transducer description and an
# NFA description from a txt file and then decide
# whether the language recognized by the NFA is
# Error-Detection to the transducer.
#
# =====================================================

from cfg import *
from common import *
from fa import *
from reex import *
from unionFind import *

if __name__ == "__main__":

    # Load input file
    inputfile = "OneWordTest.txt"
    FA = readFromFile(inputfile)

    testFA = FA[4]
    print("The input NFA is: ")
    print(testFA)

    print("This NFA accept one word?", testFA.recognizeOneWord())

    print("The language recoginzed by the NFA is: ")
    print(testFA.regexpSE())
