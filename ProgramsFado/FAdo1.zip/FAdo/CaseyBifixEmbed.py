#!/usr/bin/python
# coding=utf-8

# =====================================================
#
# This script will read a  an
# NFA description from a txt file and then 
#
# =====================================================

from cfg import *
from common import *
from fa import *
from reex import *
from unionFind import *

if __name__ == "__main__":

    # Load input file
    inputfile = "CaseyInputDFA1.txt"
    FA = readFromFile(inputfile)

    A = FA[0]
    print("The input language is: ")
    print(A.regexpSE())

    inputfile = "CaseyBifixTransducers.txt"
    FA = readFromFile(inputfile)
    T = FA[2]
    Ti = T.inverse()
    '''
    B = 
    I = 
    S =
    '''
    



    
