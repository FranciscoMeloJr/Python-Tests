import reex

#a = reex.rpn2regexp("..b+.*+**.c.+ec*.*+e+dc+.*d*e*d*.*ee..c.c+*++.*.+*cd*.a++ce.+c.++bdb*cd+a.+daabcdd+*+e*.+.a.ddab+bbe")
#print a

b = reex.str2regexp("a+a")
b = b.reduced()
print b

c = reex.str2regexp("a(a+a)(a+a)")
c = c.reduced()
print c

d = reex.str2regexp("@epsilon + a")
d = d.reduced()
print d

e = reex.str2regexp("(@epsilon)* + @epsilon")
e = e.reduced()
print e

f = reex.str2regexp("(@empty_set(aaaaa) + bbb)@epsilon*")
f = f.reduced()
print f

f = reex.str2regexp("(a+a+a@epsilon)+a")
f = f.reduced()
print f


f = reex.str2regexp("(ab)c+a(bc)")
f = f.reduced()
print f


f = reex.str2regexp("0*1*+0*")
f = f.reduced()
print f
