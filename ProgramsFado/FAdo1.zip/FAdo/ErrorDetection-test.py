#!/usr/bin/python
# coding=utf-8

# =====================================================
#
# This script will read a transducer description and an
# NFA description from a txt file and then decide
# whether the language recognized by the NFA is
# Error-Detection to the transducer.
#
# =====================================================

from cfg import *
from common import *
from fa import *
from reex import *
from unionFind import *

if __name__ == "__main__":

    # Load input file
    inputfile = "test1.txt"
    FA = readFromFile(inputfile)

    print("The input transducer is: ")
    print(FA[0])
    
    print("The language recoginzed by the NFA is: ")
    print(FA[1].regexpSE())

    #Conjuction of transducer and automaton.
    try:
        for i in FA[0].delta.keys():
            if Epsilon in FA[0].delta[i].keys():
                FA[1].addEpsilonTransition()
                break
            
        result = FA[0].__and__(FA[1])
    except FAdoGenralError, ex:
        print(str(ex))

    # Make the result transducer trim    
    result.trim()

    # Inverse the input label with output label
    result = result.inverse()

    #Conjuction of transducer result with automaton FA[1].
    try:
        for i in result.delta.keys():
            if Epsilon in result.delta[i].keys():
                FA[1].addEpsilonTransition()
                break

        finalResult = result.__and__(FA[1])
    except FAdoGeneralError, ex:
        print(str(ex))

    # Make the finalResult transducer trim    
    finalResult.trim()

    # Inverse the input label with output label
    finalResult = finalResult.inverse()

    print("The transducer to functional test is: ", finalResult)

    if (len(finalResult.Final) != 0) or (len(finalResult.delta) != 0):
        # Convert finalResult to a transducer in normal form
        normalTrans = finalResult.toNormalForm()

        # Convert normalTrans to real-time transducer
        realT = normalTrans.toRealTimeREType()

        # Make the realT transducer trim
        realT.trim()

        print("The equivalent real-time transducer after trim operation is:",\
                  realT)

        # Decide whether this real-time transducer is functional.
        # While True is functional, False is not functional.
        Functionality = realT.functionalP()
        print(Functionality)
    else:
        print("True")
