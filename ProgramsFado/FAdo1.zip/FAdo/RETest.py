#!/usr/bin/python
# coding=utf-8

from cfg import *
from common import *
from fa import *
from reex import *
from unionFind import *

if __name__ == "__main__":

    # Load input file
    inputfile = "REtest.txt"
    FA = readFromFile(inputfile)

    print(FA[3].toDFA().re_stateElimination())

    print(FA[3].wordImage(['aa']))
