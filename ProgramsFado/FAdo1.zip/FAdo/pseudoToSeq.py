#!/usr/bin/python
# coding=utf-8

from cfg import *
from common import *
from fa import *
from reex import *
from unionFind import *



if __name__ == "__main__":

    inputfile = "pseudoToSeq.txt"   
    inputfile = "seqToPseudo3.out.txt"

    a = readFromFile(inputfile)
    print(a[0])

    sequential = a[0].pseudoToSequential()
    print("Sequential transducer is: ", sequential)

    sequential.saveToFile("pseudoToSeq3.out.txt")
    
