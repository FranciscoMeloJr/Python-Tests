#!/usr/bin/python
# coding=utf-8

from cfg import *
from common import *
from fa import *
from reex import *
from unionFind import *



if __name__ == "__main__":

    inputfile = "seqToPseudo3.txt"

    a = readFromFile(inputfile)
    print(a[0])
    pseudo = a[0].sequentialToPseudo()
    print("Pseudo sequential transducer is: ", pseudo)
    pseudo.saveToFile("seqToPseudo3.out.txt")


    
    """x = AA[0].__and__(AA[1])
    print(x)
    x.trim()
    print(x)
    y = x.inverse()
    print(y)
    y.saveToFile("buffer.txt")
    print(y.__and__(AA[1]))
    AA[0].__and__(AA[1]).saveToFile("buffer.txt")
    print(AA[0].__and__(AA[1]).inverse())
    AA[0].__and__(AA[1]).inverse().saveToFile("buffer1.txt")
    print(AA[0].__and__(AA[1]).inverse().__and__(AA[1]))
    AA[0].__and__(AA[1]).inverse().__and__(AA[1]).saveToFile("buffer2.txt")"""
