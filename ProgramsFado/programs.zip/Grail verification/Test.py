#!/usr/bin/python
import Grail_validation_module
import sys

Grail_validation_module.Validate(sys.argv[0]) 
#Grail_validation_module.call() 
