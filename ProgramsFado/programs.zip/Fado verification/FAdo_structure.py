#!/usr/bin/python
#Class definition:
import sys

class MyClass:
    """A simple example class"""
    state = 0
    counter = 0
    length = -1
    Flag = False
    def return_state(self): return self.state
    def validation(self):
            if self.state==12 or self.state==13:
                    return True
            if self.state == 14 and self.Flag == True:
                    return True
            else:
                    return False
    def read(self, x):
        m=''
        print ("Begin:")
        for line in x:  
                #print line,
                print self.state,
                if self.change(line) == -1:
                    print ("Rejected")
                m = m + line
        print("END"),self.state
        return self.validation()    
    def change(self, x):#funcao de alteracao:
        try:
            if self.state == 0:#begin
                    if x is "@":
                            self.state = 1
                            self.counter = self.counter +1
                            print("@")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter -1
                            return self.state
            if self.state == 1:
                    if x is "N":
                            self.state = 2
                            self.counter = self.counter +1
                            print("N")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print(" Error")
                            return self.state
            if self.state == 2:
                    if x is "F":
                            self.state = 3
                            self.counter = self.counter +1
                            print("F")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print(" Error")
                            return self.state
            if self.state == 3:
                    if x is "A":
                            self.state = 4
                            self.counter = self.counter +1
                            print("A")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print(" Error")
                            return self.state
            if self.state == 4:
                    if x is " ":
                            self.state = 5
                            self.counter = self.counter +1
                            print(" ")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print(" Error")
                            return self.state
            if self.state == 5: #number
                    if x.isdigit() :
                            self.state = 6
                            self.counter = self.counter +1
                            print x
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print(" Error"),
                            return self.state
            if self.state == 6:
                    if x.isdigit() :
                            self.state = 6
                            self.counter = self.counter +1
                            print x
                            return self.state
                    if x is " ":
                            self.state =  5
                            self.counter = self.counter +1
                            print(" ")
                            return self.state
                    if '\n'in x:
                            self.state = 7 
                            self.counter = self.counter +1
                            print x
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print(" Error")
                            return self.state

            if self.state == 7:
                    if x.isdigit() :
                            self.state = 8
                            self.counter = self.counter +1
                            print x
                            return self.state

                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print(" Error")
                            return self.state
                                    #did
            if self.state == 8:
                    if x.isdigit() :
                            self.state = 8
                            self.counter = self.counter +1
                            print x
                            return self.state
                    if x is " ":
                            self.state = 9
                            self.counter = self.counter +1
                            print(" ")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print(" Error")
                            return self.state
            if self.state == 9:
                    if x.isdigit() :
                            self.state = 10
                            self.counter = self.counter +1
                            print x
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print(" Error")
                            return self.state
            if self.state == 10:
                    if x.isdigit() :
                            self.state = 10
                            self.counter = self.counter +1
                            print x
                            return self.state
                    if x is " ":
                            self.state = 11
                            self.counter = self.counter +1
                            print(" ")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print("Error")
                            return self.state
                    
            if self.state == 11:
                    if x.isdigit() :
                            self.state = 12
                            self.counter = self.counter +1
                            print x,
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print("Error")
                            return self.state
            if self.state == 12:#final
                    self.Flag = True
                    if x.isdigit() :
                            self.state = 12
                            self.counter = self.counter +1
                            print x,
                            return self.state
                    if '\n' in x:#jump to start or to a->b
                            self.state = 13
                            self.counter = self.counter +1
                            print("NL")
                            return self.state
                    if x is "#":
                            self.state = 14
                            self.counter = self.counter +1
                            print("@")
                            return self.state  
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print("Error")
                            return self.state
                        
            if self.state == 13:#final
                    if x.isdigit() :
                            self.state = 8#jump of the aa->b
                            self.counter = self.counter +1
                            print x
                            return self.state
                    if x is "#":
                            self.state = 14
                            self.counter = self.counter +1
                            print x
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print("Error"), x
                            return self.state
            if self.state == 14:
                    if '\n' in x:#jump to start or to a->b
                            self.state = 7
                            self.counter = self.counter +1
                            print("NL")
                            return self.state
                    else:
                            self.state = 14
                            self.counter = self.counter +1
                            print x
                            return self.state        
           
        except:
                        self.state=-1
                        return self.state
#Open a file:
fo = open(sys.argv[1], "r")
text = fo.read()

#Class operation :
x = MyClass()
if x.read(text) == True:
    print ("Accept")
else:
    print ("Reject")
fo.close()



#enquanto estiver lendo
#ver em qual estado esta:
#manda estado para classe
