#Concept:
#Take the first line until new line
#Substite the 
#!/usr/bin/python
import sys
import itertools

#Class definition
class MyClass:
    #S set:
    Set = []
    new_file=""
    length = 0
    def __init__(self, argv): #constructor:
        print "constructor",argv
        i = 0
        number = 0
        self.length = len(sys.argv) - 3
        while i < len(sys.argv) - 2:
            if argv[i+2].isdigit():
                number = argv[i+2]
            else:
                self.Set[len(self.Set):] = [argv[i+2]]
                print self.Set[i]
            i = i + 1
        self.Create(argv[1])
        self.Combination(int(number))

    def Create(self, x):
        self.new_file = open(x,'w')
        #a = raw_input('is python good?\n')
        for x in self.Set:
            self.new_file.write('@Combinations of '+x+'\n')
        #self.new_file.close()

    #write on the file:
    def Combination(self, number):
        word =''
        result = 1
        i = 1
        total = []
        while i <= number:
            items = self.Set
            accume = [[],]
            #print 'Size:', i
            for pos in range(i):
                old_accume, accume = accume, []
                for comb in old_accume:
                    for item in items:
                        accume.append(comb + [item])

            accume = [''.join(x) for x in accume]
            self.Write(str(accume)+'\n')
            #print accume
            total = total + accume 
            i = i + 1
        print total
    #Recursive function:
    def Write (self, x):
        self.new_file.write(x[0:])
        
#Operation:
print 'Number of arguments:',len(sys.argv), 'arguments.'
if len(sys.argv) > 1:
#print 'Argument List:', str(sys.argv)
#print 'first', sys.argv[1] #sys.argv[1:] all of them
    if len(sys.argv) >2:
        x = MyClass(sys.argv)
else: 
    print 'Two parameter plus the S set'
    
    
