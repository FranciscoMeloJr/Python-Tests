#!/usr/bin/python
#Class definition:
class MyClass:
    """A simple example class"""
    state = 0
    counter = 0
    length = -1
    flag = False
    def return_state(self): return self.state
    def validation(self):
            if self.state==29:
                    return True
            else:
                    return False
    def read(self, x):
        m=''
        print ("Begin:")
        for line in x:  
                #print line,
                print self.state,
                if self.change(line) == -1:
                    print ("Rejected")
                m = m + line
        print("END"),self.state
        return self.validation()    
    def change(self, x):#funcao de alteracao:
        try:
            if self.state == 0:#begin
                    if x is "(":
                            self.state = 1
                            self.counter = self.counter +1
                            print(" (")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter -1
                            return self.state
            if self.state == 1:
                    if x is "S":
                            self.state = 2
                            self.counter = self.counter +1
                            print("S")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print(" Error")
                            return self.state
            if self.state == 2:
                    if x is "T":
                            self.state = 3
                            self.counter = self.counter +1
                            print("T")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print(" Error")
                            return self.state
            if self.state == 3:
                    if x is "A":
                            self.state = 4
                            self.counter = self.counter +1
                            print("A")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print(" Error")
                            return self.state
            if self.state == 4:
                    if x is "R":
                            self.state = 5
                            self.counter = self.counter +1
                            print("R")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print(" Error")
                            return self.state
            if self.state == 5:
                    if x is "T":
                            self.state = 6
                            self.counter = self.counter +1
                            print("T")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print(" Error"),
                            return self.state
            if self.state == 6:
                    if x is ")":
                            self.state = 7
                            self.counter = self.counter +1
                            print(")")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print(" Error")
                            return self.state
            if self.state == 7:
                    if x is " ":
                            self.state = 8
                            self.counter = self.counter +1
                            print(" ")
                            return self.state  
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print(" Error")
                            return self.state
            if self.state == 8:
                    if x is "|":
                            self.state = 9
                            self.counter = self.counter +1
                            print("|")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print(" Error")
                            return self.state
            if self.state == 9:
                    if x is "-":
                            self.state = 10
                            self.counter = self.counter +1
                            print("-")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print(" Error")
                            return self.state
            if self.state == 10:
                    if x is " ":
                            self.state = 11
                            self.counter = self.counter +1
                            print(" ")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print("Error")
                            return self.state
            if self.state == 11:
                    if x.isdigit() :
                            self.state = 12
                            self.counter = self.counter +1
                            print x,
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print("Error")
                            return self.state
            if self.state == 12:#loop of start
                    if x.isdigit() :
                            self.state = 12
                            self.counter = self.counter +1
                            print x,
                            return self.state
                    if '\n' in x:#jump to start or to a->b
                            self.state = 13
                            self.counter = self.counter +1
                            print("NL")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print("Error")
                            return self.state
                        
            if self.state == 13:
                    if x is '(':
                            self.state = 1#start
                            self.counter = self.counter +1
                            print("(")
                            return self.state
                    if x.isdigit() :
                            self.state = 14#jump of the aa->b
                            self.counter = self.counter +1
                            print x
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print("Error"), x
                            return self.state   
            if self.state == 14: #lines
                    if x.isdigit() :
                            self.state = 14#loop with number
                            self.counter = self.counter +1
                            print x
                            return self.state
                    if x is ' ':
                            self.state = 15
                            self.counter = self.counter +1
                            print(" ")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print("Error"), x
                            return self.state 
            if self.state == 15: 
                    if x.isdigit() :
                            self.state = -1
                            self.counter = self.counter +1
                            print x
                            return self.state
                    if x is ' ':
                            self.state = -1
                            self.counter = self.counter +1
                            print(" ")
                            return self.state
                    if x is '-' and self.flag == True:
                            self.state = 20
                            self.counter = self.counter +1
                            print("-")
                            return self.state    
                    else:
                            self.state = 16
                            self.counter = self.counter +1
                            print("state:"), x
                            return self.state
            if self.state == 16:#the enter: 
                    if x is ' ':
                            self.state = 17
                            self.counter = self.counter +1
                            print(" ")
                            return self.state
                    if x.isdigit() :
                            self.state = -1
                            self.counter = self.counter +1
                            print x,
                            return self.state
                    if x.isalpha() :
                            self.state = 16
                            self.counter = self.counter +1
                            print x
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print x
                            return self.state
            if self.state == 17: 
                    if x.isdigit() :
                            self.state = 18
                            self.flag = True
                            self.counter = self.counter +1
                            print x
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print("error:"), x
                            return self.state
                        #will be different here
            if self.state == 18:
                    if x.isdigit() :
                            self.state = 18#recursion
                            self.counter = self.counter +1
                            print x
                            return self.state
                    if '\n' in x:
                            self.state = 19
                            self.counter = self.counter +1
                            print ("NL")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter +1
                            print("error:"), x
                            return self.state   
            if self.state == 19: 
                    if x.isdigit() :
                            self.state = 14#back to number 
                            self.counter = self.counter +1
                            print x,
                            return self.state
                    if ' ' in x:#new line
                            self.state = 19
                            self.counter = self.counter +1
                            print(" ")
                            return self.state
                    if x is '|':#go to final
                            self.state = 20
                            self.counter = self.counter +1
                            print("|")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter -1
                            return self.state             
            if self.state == 20: 
                    if x is '|':
                            self.state = 21
                            self.counter = self.counter +1
                            print("|")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter -1
                            return self.state  
            if self.state == 21:
                    if x is ' ':
                            self.state = 22
                            self.counter = self.counter +1
                            print(" ")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter -1
                            return self.state 
            if self.state == 22: 
                    if x is '(':
                            self.state = 23
                            self.counter = self.counter +1
                            print("(")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter -1
                            return self.state 
            if self.state == 23: 
                    if x is 'F':
                            self.state = 24#back to number 
                            self.counter = self.counter +1
                            print ("F")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter -1
                            return self.state 
            if self.state == 24: 
                    if x is 'I':
                            self.state = 25
                            self.counter = self.counter +1
                            print("I")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter -1
                            return self.state
            if self.state == 25: 
                    if x is 'N':
                            self.state = 26
                            self.counter = self.counter +1
                            print("N")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter -1
                            return self.state
            if self.state == 26: 
                    if x is 'A':
                            self.state = 27
                            self.counter = self.counter +1
                            print("A")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter -1
                            return self.state
            if self.state == 27: 
                    if x is 'L':
                            self.state = 28
                            self.counter = self.counter +1
                            print("L")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter -1
                            return self.state
            if self.state == 28: 
                    if x is ')':
                            self.state = 29
                            self.counter = self.counter +1
                            print(")")
                            return self.state
                    else:
                            self.state = -1
                            self.counter = self.counter -1
                            return self.state
            if self.state == 29: 
                    if x is ' ':
                            self.state = 29
                            self.counter = self.counter +1
                            print(" ")
                            return self.state
                    if '\n' in x:
                            self.state = 29
                            self.counter = self.counter +1
                            print("NL")
                            return self.state
                    if x.isdigit():
                            self.state = 14
                            self.counter = self.counter +1
                            print x
                            return self.state    
                    else:
                            self.state = -1
                            self.counter = self.counter -1
                            return self.state
        except:
                        self.state=-1
                        return self.state
#Open a file:
fo = open("Hi(2).txt", "r")
text = fo.read()

#Class operation :
x = MyClass()
if x.read(text) == True:
    print ("Accept")
else:
    print ("Reject")
fo.close()



#enquanto estiver lendo
#ver em qual estado esta:
#manda estado para classe
