#Concept:
#Take the first line until new line
#Substite the 
#!/usr/bin/python
import sys
#Class definition
class MyClass:
    #S set:
    array = []
    new_file=""
    count = 0
    total = ''
    S = False
    def __init__(self, name, argv): #constructor:
        print "constructor",argv
        i = 0
        while i < len(sys.argv) - 2:
            self.array[len(self.array):] = [argv[i+2]]
            print self.array[i]
            i = i + 1
        temp=self.New_name(name)
        self.Create(name,temp)
        
    #Function to create the file
    def New_name(self, x):
        temp = x.replace('.','[2].')
        return temp
    
    def Create(self, x, y):
        self.new_file = open(y,'w')
        #a = raw_input('is python good?\n')
        self.new_file.write('@Copy of '+x+'\n')
        #self.new_file.close()
    #substitute the S for the set behind    
    def Subs (self, x):
        count = 0
        while count < len(self.array):
            i = 0
            temp = ''
            for line in x:
                if x[i]!= 'S':
                    temp = temp + x[i]
                else:
                    temp = temp + self.array[count]
                i = i + 1
            self.new_file.write(temp)
            count = count +1
    #write on the file:
    def Write (self, x):
        self.count = self.count +1
        if '\n' in x:
            self.total = self.total + x
            if self.S == False:
                print self.total
                self.new_file.write(self.total)
            else:
                print self.total
                self.Subs(self.total)
                self.S = False
            self.total=''
        else:
            self.total= self.total + x
            if x == 'S':
                self.S = True
    def Read(self, x):
        for line in x:  
            self.Write(line)
        self.new_file.close()
#Operation:
print 'Number of arguments:',len(sys.argv), 'arguments.'
if len(sys.argv) > 1:
#print 'Argument List:', str(sys.argv)
#print 'first', sys.argv[1] #sys.argv[1:] all of them
    print 'File enter by user'
    name = sys.argv[1] #take the first argument
    fo = open(name, "r")
    text = fo.read()
    if len(sys.argv) >2:
        x = MyClass(name,sys.argv)
        x.Read(text)
else: 
    print 'Two parameter plus the S set'
    
    
