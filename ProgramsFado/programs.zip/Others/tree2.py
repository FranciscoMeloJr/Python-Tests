class Node:
    """
    Tree node: left and right child + data which can be any object
    """
    def __init__(self, data):
        """
        Node constructor
        """
        self.left = None
        self.right = None
        self.data = data
    def insert(self, data):
        """
        Insert new node with data
        @param data node data object to insert
        """
        if data < self.data:
            if self.left is None:
                self.left = Node(data)
            else:
                self.left.insert(data)
        else:
            if self.right is None:
                self.right = Node(data)
            else:
                self.right.insert(data)
    def print_tree(self):
        """
        Print tree content inorder
        """
        if self.left:
            print 'L'
            self.left.print_tree()
        print self.data,
        if self.right:
            print 'R'
            self.right.print_tree()
    def inorder(self,node):
           if node is not None:
              self.inorder(node.left)
              print node.data
              self.inorder(node.right)
 
 
    def preorder(self,node):
           if node is not None:              
              print node.data
              self.preorder(node.left)
              self.preorder(node.right)
 
 
    def postorder(self,node):
            print 'Postorder:'
            if node is not None:
              self.postorder(node.left)
              self.postorder(node.right)
              print node.data,
    def compare_trees(self, node):
        """
        Compare 2 trees
        @param node tree's root node to compare to
        @returns True if the tree passed is identical to this tree
        """
        if node is None:
            return False
        if self.data != node.data:
            return False
        res = True
        if self.left is None:
            if node.left:
                return False
        else:
            res = self.left.compare_trees(node.left)
        if self.right is None:
            if node.right:
                return False
        else:
            res = self.right.compare_trees(node.right)
        return res
    
arr = [11,10,9,3,1,6,4,7,10,14,13]
for i in arr:
      print i
      root = Node(i)
root.postorder(root)
root.print_tree()

