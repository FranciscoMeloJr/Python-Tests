#!/usr/bin/python
# Filename: mymodule_demo.py
import mymodule

mymodule.sayhi('hey')
print 'Version', mymodule.version
