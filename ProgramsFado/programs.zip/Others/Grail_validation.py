#!/usr/bin/python
# Filename: mymodule.py

def sayhi(x):
	print 'Hi',x
        
version = '0.1'

# End of mymodule.py
			
