import sys

#!/usr/bin/python
#Class definition:
class MyClass:
    """A simple example class"""
    state = 0
    counter = 0
    flag = False
    def return_state(self):
        return self.state
    def validation(self):
            if self.state==2:
                    return True
            else:
                    print 'Expect complete sentence'
                    return False
    def simbol(self, x):
        if x is '+' or x is '-' or x is '*' or x is '/':
                return True
        return False
    def error(self):
        if self.state is 3:
            print 'Expected digit at the beginning or +/- in', self.counter
        if self.state is 4:
            print 'Expected digit after + or - in', self.counter
        if self.state is 5:
            print 'Invalid character in', self.counter
            
    def validate(self, x ):
        if str(x).isdigit()!= True and self.simbol(x)!= True:
            self.state = 5
            self.flag = True
            
    def read(self, x):
        m=''
        #print 'Begin'
        for line in x:  
                #print self.state
                self.counter = self.counter +1
                self.validate(line)
                self.change(line)
                if self.flag != False:
                    self.error()
                    return False
                m = m + line
        #print("END"),self.state
        return self.validation()    
    def change(self, x):#funcao de alteracao:
        try:
            if self.state == 0:#begin
                    if x is "+" or x is "-":
                            self.state = 1
                            print x,
                            return self.state
                    if str(x).isdigit():
                            print x
                            self.state = 2
                            print x,
                            return self.state
                    else:
                            self.state = 3
                            self.flag = True
                            return self.state
            if self.state == 1:
                    if str(x).isdigit():
                            self.state = 2
                            print x
                            return self.state
                    else:
                            self.state = 4
                            self.flag = True
                            print(" Error")
                            return self.state
            if self.state == 2:
                    if str(x).isdigit():
                            self.state = 2
                            print x
                            return self.state
                    if self.simbol(x)!=False:
                            self.state = 1
                            print x
                            return self.state   
                    else:
                            self.state = -1
                            self.flag = True
                            print(" Error")
                            return self.state          
        except:
                        self.state=-1
                        return self.state
#Class operation :
print 'Number of arguments:',len(sys.argv), 'arguments.'
name = 'Default.txt'
if len(sys.argv) > 1:
    name = sys.argv[1] #take the first argument    
fo = open(name, "r")
text = fo.read()
if len(sys.argv) > 2 and sys.argv[2] == 'Y':
        print text
        
x = MyClass()
if x.read(text) == True:
    print ("Accept")
else:
    print ("Reject")
fo.close()


#enquanto estiver lendo
#ver em qual estado esta:
#manda estado para classe
